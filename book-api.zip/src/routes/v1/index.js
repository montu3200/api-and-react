const express = require('express');
const authRoute = require('../../api/auth/auth.route');
const bookRoute = require('../../api/book/book.route');
const router = express.Router();

router.use('/auth', authRoute);
router.use('/book',bookRoute)

module.exports = router;
