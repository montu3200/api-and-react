const httpStatus = require('http-status');
const catchAsync = require('../../utils/catchAsync');
const createResponse = require('../../utils/response');
const auth = require('../../middlewares/auth');
const Messages = require('../../utils/messages');
const authService = require("./auth.service");
const tokenService = require("../common/token.service");
const bcrypt = require("bcryptjs");
const {Userdata,Activity,DeviceToken} = require("../../models/");
const moment = require('moment');
const AppError = require("../../utils/AppError");

const login = catchAsync(async (req, res) => {
  let { sEmail, sPassword } = req.body;
  const user = await authService.login(sEmail, sPassword);
  const tokens = await authService.generateAuthTokens(user.transform());
  const response = { user: user.transform(), tokens };
  createResponse(res, httpStatus.OK,Messages.LOGIN, response)
});


const register = catchAsync(async (req, res) => {
  const user = await authService.CreateRegister(req.body);
  const response = { user: user.transform()};
  createResponse(res, httpStatus.OK, Messages.SIGNUP, user);
});
const updateProfile = catchAsync(async (req, res) => {
  const user = await authService.UserUpdate(req.user._id,req.body);
  createResponse(res, httpStatus.OK, Messages.UPDATE_DATA, user);
});
const deleteProfile = catchAsync(async (req, res) => {
  const user = await authService.deleteUser(req.user._id,req.body);
  createResponse(res, httpStatus.OK, Messages.ACCOUNT_DELETED, user);
});
module.exports = {
  login,
  register,
  updateProfile,
  deleteProfile
};
