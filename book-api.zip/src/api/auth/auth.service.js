const moment = require('moment');
const bcrypt = require('bcryptjs');
const Userdata = require("../../models/user.model");
const Booking = require("../../models/book.model")
const httpStatus = require('http-status');
const config = require('../../config/config');
const commonService = require('../common/common.service');
const tokenService=require('./../common/token.service')

const AppError = require('../../utils/AppError');
const { TOKEN_TYPE, ROLES, STATUS } = require('../../config/constant');
const Messages = require('../../utils/messages');
const mongoose=require('mongoose');
const ObjectId=mongoose.Types.ObjectId

const generateAuthTokens = async (dataobj) => {
  const accessTokenExpires = moment().add(config.jwt.accessExpirationMinutes, 'day').unix();
  console.log(accessTokenExpires)
  const accessToken = tokenService.generateToken(dataobj, accessTokenExpires);

  return {
    access: {
      token: accessToken,
      expires: accessTokenExpires,
    }
  };
};
const checkUser = async (email) => {
  let check = await Userdata.find({ sEmail: email })
  if (check.length != 0) {
    throw new AppError(httpStatus.FORBIDDEN, __('ALREADY_EXITS'));
  }
}

const CreateRegister = async (data) => {
  await checkUser(data.sEmail);
  let otp = await commonService.generateOtp();
  data = {
    ...data,
    nOtp: parseInt(otp),
  };
  // console.log(data);
  let user = await Userdata(data).save();
  // const accessTokenExpires = moment().add(config.jwt.accessExpirationMinutes, 'minutes').unix();
  // let token = await tokenService.generateToken(data, accessTokenExpires);
  // user.token = token;
  // // await emailService.sendUserVerify(data.sEmail, user);
  // await user.save();
  // console.log("Saved User,,,,,,,,, :",user)
  return user;
};

const checkPassword = async (password, correctPassword) => {
  const isPasswordMatch = await bcrypt.compare(password, correctPassword);
  console.log("Password Match function ",isPasswordMatch);
  if (!isPasswordMatch) {
    throw new AppError(httpStatus.UNPROCESSABLE_ENTITY, __('PASSWORD_INCORRECT'));
  }
};
const login = async (email, password) => {
  let user = await Userdata.findOne({ sEmail: email })
  if (user) {
    await checkPassword(password, user.sPassword);
    return user
  } else {
    throw new AppError(httpStatus.UNPROCESSABLE_ENTITY,Messages.EMAIL_NOT_FOUND);
  }
};
const UserUpdate = async (id, body) => {
  let updateData =body
  let data = await Userdata.findByIdAndUpdate(id, updateData,{new:true});
  return data
}
const deleteUser = async (id) => {
  let data = await Userdata.deleteOne({_id:id});
  return data
}

const updateProfile = async (id, data) => {
  return await Userdata.findByIdAndUpdate({ _id: id }, data, { new: true });
};


module.exports = {
  generateAuthTokens,
  login,
  checkResetLink,
  CreateRegister,
  UserUpdate,
  deleteUser
};
