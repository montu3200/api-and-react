const Joi = require('@hapi/joi');
const { password } = require('../common/custom.validation');
const { ROLES, GENDER, USER_TYPE, SOCIALMEDIA_TYPE } = require('../../config/constant')
const register = {
  body: Joi.object().keys({
    sFirstName: Joi.string().required(),
    sLastName: Joi.string().required(),
    sEmail: Joi.string()
      .required()
      .email(),
    sPassword: Joi.string()
      .custom(password),
      nPhone: Joi.string(),
  }),
};
const updateUser = {
  body: Joi.object().keys({
    sFirstName: Joi.string().required(),
    sLastName: Joi.string().required(),
    nPhone: Joi.string(),
  }),
};
const login = {
  body: Joi.object().keys({
    sEmail: Joi.string().email().required().messages({
      'string.email': "Are you sure you entered the valid email address?",
      'string.empty': "Email address cannot be empty."
    }),
    sPassword: Joi.string().required().messages({
      'string.empty': "Password cannot be empty."
    }),
  }),
};
const checkResetLink = {
  query: Joi.object().keys({
    token: Joi.string().required()
  })
}
const resetPassword = {
  query: Joi.object().keys({
    token: Joi.string().required()
  }),
  body: Joi.object().keys({
    password: Joi.string()
      .required()
      .custom(password)
      .messages({
        'string.empty': "New password cannot be empty."
      }),
  })
}

const forgotPassword = {
  body: Joi.object().keys({
    sEmail: Joi.string()
      .email()
      .required().messages({
        'string.email': "Are you sure you entered the valid email address?",
        'string.empty': "Email address cannot be empty."
      }),

  })
};
const refreshTokens = {
  body: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};
// const setRole = {
//   query: Joi.object().keys({
//     email: Joi.string().email().required(),
//     sUserRole: Joi.string().required(),
//   }),
// };
const changepassword = {
  body: Joi.object().keys({
    sPassword: Joi.string().required(),
  }),
};
const MangopayCustomerId = {
  query: Joi.object().keys({
    MangoCustomerId: Joi.string().required().messages({
      "string.empty": "Mangopay customer id cannot be empty.",
    })
  }),
};

const ResendToken = {
  body: Joi.object().keys({
    email: Joi.string().email().required().messages({
      "string.email": "Are you sure you entered the valid email address?",
      "string.empty": "Email address cannot be empty.",
    }),
  }),
};



const GetShakerFinanceTotal = {
  query: Joi.object().keys({
    fromDate: Joi.string(),
    toDate:Joi.string(),
    activity:Joi.array()
  }),
};

const contactUs = {
  body: Joi.object().keys({
    message: Joi.string().required().messages({
      "string.empty": "message cannot be empty.",
    }),
  }),
}
module.exports = {
  login,
  checkResetLink,
  resetPassword,
  forgotPassword,
  register,
  refreshTokens,
  //setRole,
  changepassword,
  ResendToken,
  updateUser,
  MangopayCustomerId,
  GetShakerFinanceTotal,
  contactUs,
  updateUser
};
