const CryptoJS = require("crypto-js");
const moment = require("moment");
const { Token } = require('./../../models');
const config = require('../../config/config');
const AppError = require('../../utils/AppError');
const httpStatus = require('http-status');
const message = require('../../utils/messages')
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const generateToken = (data, expires, secret = config.jwt.secret) => {
  let payload = {
    ...data,
    iat: moment().unix(),
    exp: expires,
  };
  console.log(payload);
  var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(payload), secret).toString().replace(/\+/g,'xMl3Jk').replace(/\//g,'Por21Ld').replace(/=/g,'Ml32');
  // var chars = { '/': 'Por21Ld' };
  // var final = ciphertext;
  // final = final.replace(/[/]/g, m => chars[m]);
  return ciphertext
};
const saveToken = async (token, userId, expires, type, sUserRole, blacklisted = false) => {
  var d = new Date(expires);
  const tokenDoc = await Token.create({
    token,
    oUserId: userId,
    expiresAt: d,
    type,
    blacklisted,
    sUserRole: sUserRole
  });
  return tokenDoc;
};
const verifyToken = async (token, type) => {
  console.log("Token", token,"Type :",type);
  let text;
    switch(type) {
      case 3:
        text=__('VERIFYLINKEXPIRE')
        break;
      case 4:
        text=__('FORGOTPASSWORDTOKENEXPIRE')
        break;
      default:
        text="Token is Expire"
    }
  // var chars = { 'Por21Ld': '/' };
  let newtoken = token.replace(/xMl3Jk/g,'+').replace(/Por21Ld/g,'/').replace(/Ml32/g,'=');
  console.log("newtoken",newtoken)
  var bytes = CryptoJS.AES.decrypt(newtoken, config.jwt.secret);
  console.log("bytes", bytes);
  var originalText = await bytes.toString(CryptoJS.enc.Utf8);
  console.log("origibnal",originalText)
  if (/^[\],:{}\s]*$/.test(originalText.replace(/\\["\\\/bfnrtu]/g, '@').
    replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
    replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
    let data = JSON.parse(originalText)

    // let timestamp = moment().unix()
    // var difference = data.exp - timestamp

    // console.log("originalText",originalText,"DAta",data,"timestamp",timestamp,"difference",difference,"DAta.id",data.id);
    
    if (data.id) { data._id = data.id }
    console.log("data_id",data._id)
 
  //  if (difference > 0) {
      const tokenDoc = await Token.findOne({ token, oUserId: data._id });
      if (!tokenDoc) {
        throw new AppError(httpStatus.NOT_FOUND, 'Token not found');
      } else {
        return tokenDoc
      }
  //  } else {
  //    throw new AppError(httpStatus.UNAUTHORIZED, text);
   // }
  } else {
    throw new AppError(httpStatus.UNAUTHORIZED, 'Invalid Token');
  }
 return tokenDoc;
};
module.exports = {
  generateToken, saveToken, verifyToken
};