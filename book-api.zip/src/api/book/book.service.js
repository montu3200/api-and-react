const moment = require("moment");
const mongoose = require("mongoose");
const httpStatus = require("http-status");
const config = require("../../config/config");
const AppError = require("../../utils/AppError");
const Messages = require("../../utils/messages");
const Book= require('../../models/book.model');
const Userdata = require('../../models/user.model');
const authService = require('../auth/auth.service');
const orders = require('../../models/order.model');
const ObjectId = mongoose.Types.ObjectId;

const updateBook = async (id,data) => {
    const updateBookDetails= await Book.findByIdAndUpdate(id,data,{new:true});
    if (!updateBookDetails) {
      throw new AppError(httpStatus.FORBIDDEN, __('ALREADY_EXITS'));
    }
    return updateBookDetails
  }
  const deleteBook = async (id) => {
    const deleteBooks= await Book.deleteOne({_id:id});
    return deleteBooks
  }
  const getBook = async () => {
    const books= await Book.find().sort({_id:-1}).populate('oUserId');
    return books
  }
  const createOrder = async (body) =>{
    const bookdetails= await Book.findById(body.oBookId);
    if(bookdetails){
      const orderdetails=await orders(body).save();
      await Book.findByIdAndUpdate(body.oBookId,{$inc:{nStock:-1}})
      return orderdetails
    }else{
      throw new AppError(httpStatus.FORBIDDEN, Messages.NOTEXITBOOK);
    }
    
  }
module.exports = {
    updateBook,
    deleteBook,
    getBook,
    createOrder
};