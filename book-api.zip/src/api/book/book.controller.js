const catchAsync = require("../../utils/catchAsync");
const createResponse = require("../../utils/response");
const mongoose = require("mongoose");
const Book = require('../../models/book.model');
const bookServices = require('./book.service');
const ObjectId = mongoose.Types.ObjectId;
const moment = require('moment');
const httpStatus = require("http-status");
const Messages = require('../../utils/messages');

const addBook = catchAsync(async (req, res) => {
    const addBook=await Book(req.body).save();
    createResponse(res, httpStatus.OK,Messages.ADDBOOK, addBook)
  });
const updateBook = catchAsync(async (req, res) => {
    const updateBook=await bookServices.updateBook(req.params.id,req.body)
    createResponse(res, httpStatus.OK,Messages.ADDBOOK, updateBook)
});
const deleteBook = catchAsync(async (req, res) => {
    const updateBook=await bookServices.deleteBook(req.params.id);
    createResponse(res, httpStatus.OK,Messages.ADDBOOK, updateBook)
});
const getBook = catchAsync(async (req, res) => {
    const Book=await bookServices.getBook();
    createResponse(res, httpStatus.OK,Messages.ADDBOOK, Book)
});
const createOrder = catchAsync(async (req, res) => {
    const Book=await bookServices.createOrder(req.body);
    createResponse(res, httpStatus.OK,Messages.ORDER_CREATE, Book)
});
module.exports = {
    addBook,
    updateBook,
    deleteBook,
    getBook,
    createOrder
};