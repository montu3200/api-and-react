const Joi = require("@hapi/joi");

const addbook = {
  body: Joi.object().keys({
    oUserId:Joi.string().required(),
    sName: Joi.string().required(),
    sAuthor: Joi.string().required(),
    nPrice: Joi.number()
      .required(),
    nStock: Joi.number().required(),
  }),
};
const updatebook = {
  body: Joi.object().keys({
    sName: Joi.string().required(),
    nPrice: Joi.number()
      .required(),
    nStock: Joi.number().required(),
  }),
};

const createOrder = {
  body: Joi.object().keys({
    oUserId: Joi.string().required(),
    oBookId: Joi.string().required(),
    nPrice: Joi.number()
      .required(),
  }),
};

module.exports = {
  addbook,
  updatebook,
  createOrder
  };
  