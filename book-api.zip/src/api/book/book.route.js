const express = require("express");
const auth = require("../../middlewares/auth");
const validate = require("../../middlewares/validate");
const bookValidation = require("./book.validation");
const bookController = require("./book.controller");
const router = express.Router();
router.post('/',auth(), validate(bookValidation.addbook), bookController.addBook);
router.put('/:id',auth(), validate(bookValidation.updatebook), bookController.updateBook);
router.delete('/:id',auth(),  bookController.deleteBook);
router.get('/',  bookController.getBook);
router.post('/createOrder', auth(),validate(bookValidation.createOrder), bookController.createOrder);

 module.exports = router;