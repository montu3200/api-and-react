const { ROLES } = require('../config/constant')
const roles = ["User"];

const roleRights = new Map();
roleRights.set(roles[0], ['getdetails']);

module.exports = {
  roles,
  roleRights,
};
