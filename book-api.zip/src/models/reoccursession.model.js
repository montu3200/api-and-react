var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var reoccursessionSchema = new Schema(
  {
    sParentSessionId: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "session", // Parent Session
    },
    sActivityId:{
      type: Schema.Types.ObjectId,
      required: true,
      ref: "activity", // Parent Session
    },
    sCreatedBy: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "user", // session create by user
    },
    sSessionStart: {
      type: Date,
    },
    sSessionEnd: {
      type: Date,
    },
    sSessionRepeat: {
      type: String,
      enum: [
        "Daily",
        "Weekly on Monday",
        "Weekly on Tuesday",
        "Weekly on Wednesday",
        "Weekly on Thursday",
        "Weekly on Friday",
        "Weekly on Saturday",
        "Weekly on Sunday",
        "Every weekday",
        "Every weekend",
        "Custom",
      ],
    },
    sStatus: {
      type: String,
      enum: [
        "Pending",
        "Completed",
        "Cancelled",
        "Deleted",
      ],
      default: "Pending"
    },
    sBookedSlot:{
      type: Number,
      default: 0
    },
    sTotalReview:{
      type: Number,
      default:0
    },
    sAverageReview:{
      type: Number,
      default:0
    },
    isEdit:{
      type: Boolean,
      default: false
    }
  },
  {
    timestamps: true,
    toObject: { getters: true },
    toJSON: { getters: true },
  }
);
reoccursessionSchema.index({ location: "2dsphere" });
const Tokens = mongoose.model("reoccursession", reoccursessionSchema);

module.exports = Tokens;
