const { number } = require('@hapi/joi');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const { omit, pick } = require('lodash');
const userSchema = mongoose.Schema(
  {
    id:{
      type:Number,
    },
    sFirstName: {
      type: String,
      require: true,
    },
    sLastName: {
      type: String,
      require: true,
    },
    sEmail: {
      type: String,
    },
    sPassword: {
      type: String,
    },
    nPhone: String,
    sUserRole: {
      type: String,
      enum: ["User"],
      default: "User",
    },
  },
  {
    timestamps: true,
    toObject: { getters: true },
    toJSON: { getters: true },
  },
);
userSchema.methods.transform = function () {
    const user = this;
    return pick(user.toJSON(), ['_id', 'id','sFirstName', 'sLastName', 'createdAt', 'sEmail', 'nPhone']);
};
userSchema.pre('save', async function (next) {
    const user = this;
    user.sPassword = await bcrypt.hash(user.sPassword, 8);
    let userDetails=await UserData.findOne().sort({_id:-1}).limit(1);
    if(userDetails){
      user.id=userDetails.id + 1
    }else{
      user.id=1
    }
    next();
});
const UserData = mongoose.model('users', userSchema);

module.exports = UserData;