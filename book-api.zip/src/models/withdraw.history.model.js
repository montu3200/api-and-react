var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var ratingSchema = new Schema(
  {
    shakerId:{
      type: Schema.Types.ObjectId,
      required: true,
      ref: "users" // Session Id
    },
    amount:{
      type: Number
    },
    withdrawId:{
        type: String
      },
    status:{
        type: String,
    },
    message:String,
    BankAccountId:String,
    PaymentType:String
  },
  {
    timestamps: true,
    toObject: { getters: true },
    toJSON: { getters: true },
  }
);
//bookingSchema.index({ location: "2dsphere" });
const Withdraw = mongoose.model("withdraw_history", ratingSchema);

module.exports = Withdraw;
