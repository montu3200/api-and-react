const { array } = require("@hapi/joi");
var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var sessionSchema = new Schema(
  {
    sActivityId: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "activity", // session create under Activity
    },
    sCreatedBy: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "user", // session create by user
    },
    sOldSessionId:{
      type: Schema.Types.ObjectId,
      ref: "session", // Parent Session
    },
    sSessionStart: {
      type: Date,
    },
    sSessionEnd: {
      type: Date,
    },
    sSessionRepeat: {
      type: String,
      enum: [
        "Daily",
        "Weekly on Monday",
        "Weekly on Tuesday",
        "Weekly on Wednesday",
        "Weekly on Thursday",
        "Weekly on Friday",
        "Weekly on Saturday",
        "Weekly on Sunday",
        "Every weekday",
        "Every weekend",
        "Custom",
        "false"
      ],
    },
    sMaxGroup: {
      type: Number,
    },
    sPrice: {
      type: Number,
    },
    sDuration: {
      type: Number,
    },
    sOfferedLanguage: {
      type: Array,
      default: [],
    },
    sLevel: {
      type: Array,
      required: true
    },
    sEquipmentRequired: {
      type: Boolean,
    },
    sEquipmentDescription: {
      type: String
    },
    location: {
      type: {
        type: String, // Don't do `{ location: { type: String } }`
        enum: ["Point"], // 'location.type' must be 'Point'
      },
      coordinates: {
        type: [Number],
      },
    },
    sAddress: {
      type: String
    },
    sAcceptCash:{
        type: Boolean
    },
    sCancellationPolicy: {
        type: String,
        enum: ["Free", "48 hours", "24 hours"],
    },
    sIsCreated:{
        type: Boolean
    },
    sReoccuringSession:{
        type: Boolean
    },
    isPaid:{
        type: Boolean,
        default: false
    },
    PaymentDetails:{
      type:Array,
      default:[]
    },
    sActivity: {
      type: Array,
      require: true,
    },
    sDisplayActivity: {
      type: Array,
      require: true,
    },
    sCustomeDate:{
      type: Array
    },
    isEdit:{
      type: Boolean,
      default: false
    }
  },
  {
    timestamps: true,
    toObject: { getters: true },
    toJSON: { getters: true },
  }
);
sessionSchema.index({ location: "2dsphere" });
const Tokens = mongoose.model("sessions", sessionSchema);

module.exports = Tokens;
