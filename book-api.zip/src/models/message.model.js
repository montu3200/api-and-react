
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var messageSchema = new Schema({
    type:{
        type: String
    },
    message:[{
        question: String,
        answer: String
    }]
}, {
  timestamps: true,
  toObject: { getters: true },
  toJSON: { getters: true },
});

const Messages = mongoose.model('messages', messageSchema);

module.exports = Messages;