var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var ratingSchema = new Schema(
  {
    sBookingId:{
        type: Schema.Types.ObjectId,
        required: true,
        ref: "booking" //Booking Id
    },
    sSessionId:{
      type: Schema.Types.ObjectId,
      required: true,
      ref: "reoccursession" // Session Id
    },
    sActivityId:{
      type: Schema.Types.ObjectId,
      required: true,
      ref: "activity" // Activity Id
    },
    sReviewBy:{
        type: Schema.Types.ObjectId,
        required: true,
        ref: "user" //Moovver Id
    },
    sRating:{
        type: Number,
        enum:[1,2,3,4,5]
    },
    sReviewDescription:{
        type: String
    }
  },
  {
    timestamps: true,
    toObject: { getters: true },
    toJSON: { getters: true },
  }
);
//bookingSchema.index({ location: "2dsphere" });
const Rating = mongoose.model("ratings", ratingSchema);

module.exports = Rating;
