var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var ObjectId = mongoose.Schema.Types.ObjectId

var orderSchema = new Schema(
  
  {
    id:Number,
    oUserId:{
      type:ObjectId,
      ref:'users'
    },
    oBookId:{
      type:ObjectId,
      ref:'books'
    },
  },
  {
    timestamps: true,
    toObject: { getters: true },
    toJSON: { getters: true },
  }
);
orderSchema.pre('save', async function (next) {
  const order = this;
  let orderDetails=await orders.findOne().sort({_id:-1}).limit(1);
  if(orderDetails){
    order.id=bookDetails.id + 1
  }else{
    order.id=1
  }
  next();
});
const orders = mongoose.model("orders", orderSchema);

module.exports = orders;
