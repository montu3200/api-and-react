var mongoose = require("mongoose");
var ObjectId = mongoose.Schema.Types.ObjectId

var DevictTokenSchema = new mongoose.Schema({
    user: ObjectId,
    deviceToken: String,
    deviceType: String,
},
{
    versionKey: false
});
const Documents = mongoose.model('deviceTokens', DevictTokenSchema);
module.exports = Documents;

