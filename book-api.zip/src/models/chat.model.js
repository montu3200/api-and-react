var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var ratingSchema = new Schema(
  {
    sSpaceId:{
        type: String,
        required: true,
    },
    sShakerId:{
      type: Schema.Types.ObjectId,
      required: true,
      ref: "user" // Session Id
    },
    sMoovverId:{
      type: Schema.Types.ObjectId,
      required: true,
      ref: "user" // Activity Id
    }
  },
  {
    timestamps: true,
    toObject: { getters: true },
    toJSON: { getters: true },
  }
);
//bookingSchema.index({ location: "2dsphere" });
const Chatting = mongoose.model("chat", ratingSchema);

module.exports = Chatting;
