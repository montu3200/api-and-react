var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var ObjectId = mongoose.Schema.Types.ObjectId
var bookSchema = new Schema(
  {
    id:Number,
    oUserId:{
      type:ObjectId,
      ref:'users'
    },
    sName:String,
    sAuthor:String,
    nPrice:Number,
    nStock:{
        type:Number,
        default:0
    }
  },
  {
    timestamps: true,
    toObject: { getters: true },
    toJSON: { getters: true },
  }
);

bookSchema.pre('save', async function (next) {
  const book = this;
  let bookDetails=await Book.findOne().sort({_id:-1}).limit(1);
  if(bookDetails){
    book.id=bookDetails.id + 1
  }else{
    book.id=1
  }
  next();
});
const Book= mongoose.model("books", bookSchema);
module.exports = Book;
