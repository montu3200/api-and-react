import React, { lazy } from 'react';
import AdminLayout from './layout/Admin/index';

import Customer from './pages/Admin/Customer/Customer';
import CustomerDetails from './pages/Admin/CustomerDetails/CustomerDetails';
import PageNotFound from './pages/PageNotFound/PageNotFound';
const routes = [
    {
        path: '/*',
        component: <AdminLayout />,
        authenticate: false,
        exact: true
    }
];


export const AdminLayoutRoute = [
    {
        path: '/customer',
        component: <Customer />,
        exact: true,
        authenticate: true
    },
    {
        path: '/customer/customerdetails',
        component: <CustomerDetails />,
        exact: true,
        authenticate: true
    },
    {
        path: '/admin/*',
        component: <PageNotFound />,
        authenticate: false,
        exact: true
    }
];


export default routes;
