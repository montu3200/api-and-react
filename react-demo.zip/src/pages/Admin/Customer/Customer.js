import React, { useEffect, useState } from "react";
import { multilanguage } from "redux-multilanguage";
import { connect } from "react-redux";
import { Dropdown } from 'react-bootstrap';

import useWindowDimension from "../../../hooks/useWindowDimension";
import { showToast } from "../../../redux/actions/toastAction";
import {setBook} from "../../../redux/actions/bookActions";
import SearchBox from "../../../assets/components/UI/SearchBox/SearchBox";
import CustomToggleButton from "../../../assets/components/UI/CustomToggleButton/CustomToggleButton";
import ModalPopup from "../../../assets/components/UI/ModalPopup/ModalPopup";
import CustomButton from "../../../assets/components/UI/CustomButton/CustomButton";
import DropDownCheckBox from "../../../assets/components/UI/DropDownCheckBox/DropDownCheckBox";
import axios from 'axios';
import "./Customer.scss";
import { useNavigate } from "react-router-dom";

const Customer = (props) => {
  let { strings } = props;
  const navigate = useNavigate();
  const dimensions = useWindowDimension();
  const [headerHeight, setHeaderHeight] = useState(0);
  const [searchText, setSearchText] = useState("");

  const [statusValue, setStatusValue] = useState(null);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [userList, setUserList] = useState([]);
  const [customerDetail, setCustomerDetail] = useState('');

  const [customerTypeLength, setCustomerTypeLength] = useState(0)
  const [customerTypeList, setCustomerTypeList] = useState([]);
  const onChangeCustomerType = (status, id) => {
    setCustomerTypeLength(status === true ? customerTypeLength + 1 : customerTypeLength - 1)
    let dupCustomerTypeList = JSON.parse(
      JSON.stringify(customerTypeList)
    );
    for (var i = 0; i < dupCustomerTypeList.length; i++) {
      if (dupCustomerTypeList[i].id === id) {
        dupCustomerTypeList[i].isSelected = status;
      }
    }
    setCustomerTypeList([...dupCustomerTypeList]);
  };
  const CustomerTypeData = [
    {
      id: "1",
      title: "A-Z",
      value: {sName:1},
      isSelected: false,
    },
    {
      id: "2",
      title: "A-Z",
      value: {sName:-1},
      isSelected: false,
    }
  ];

  const [properySizeLength, setProperySizeLength] = useState(0);
  const [properySizeList, setProperySizeList] = useState([]);

  const [themesAttendedLength, setThemesAttendedLength] = useState(0);
  const [themesAttendedList, setThemesAttendedList] = useState([]);

  const tableHeader = [
    { id: 1, title: strings['ID'], sorting: false },
    { id: 2, title: "name", sorting: false, },
    { id: 3, title: "author", sorting: false, },
    { id: 4, title: "price", sorting: false, },
    { id: 5, title: "stock", sorting: false, },
    { id: 6, title: "ownername", sorting: false }
  ]
  const tableBody = [
    {
      id: 1,
      sName: 'Devon Lane',
      sAuthor: 'Postcode: CB25 9HY Greenwich Park, London',
      nPrice: 'johnny.cooper@gmail.com',
      nStock:5,
      ownername:"test"
    }
  ]

  useEffect(() => {
    setHeaderHeight(document.getElementsByClassName("adminHeader")[0]?.offsetHeight);
    
  }, []);
  useEffect(()=>{
    axios.get("http://localhost:4000/v1/book/").then(res => {
      setUserList(res.data.payload)
    }).catch (error=>{
        
    })
  })

  const onProcced = async () => {
    setShowStatusModal(false);
    let dupData = JSON.parse(JSON.stringify(userList));
    for (var i = 0; i < dupData.length; i++) {
      if (dupData[i].id === statusValue.id) {
        dupData[i].status = statusValue.value === true ? 'Enable' : 'Disable'
      }
    }
    setUserList([...dupData]);
    props.showToast({
      message: statusValue?.value ? `${customerDetail?.fullNmae + ' ' + strings['ENABLED_SUCCESSFULLY']} ?` : `${customerDetail?.fullNmae + ' ' + strings['DISABLED_SUCCESSFULLY']} ?`,
      type: "success",
    });
  }

  const onPressDeleteCustomer = async () => {
    setShowDeleteModal(false);
    props.showToast({
      message: customerDetail?.fullNmae + ' ' + strings['DELETED_SUCCESSFULLY'],
      type: "success",
    });
  };

  const onPressClearAll = () => {
    setThemesAttendedLength(0);
    setProperySizeLength(0);
    setCustomerTypeLength(0);
  };

  return (
    <>
      <div className="customerMain" style={{ paddingTop: headerHeight }}>
        <div className="customerBack" style={{ height: dimensions.height - headerHeight + "px" }}>
          <div className="customerCenter">
            <h1 className="title">Manage Book</h1>
            

            <div className="customerTblMain">

              <div className="tableScroll">

                <div className="tblHeader">
                  <ul>
                    {tableHeader.map((item) => {
                      return (
                        <li>{(item.title)} {(item.sorting === true && tableBody.length !== 0) && <i className="icon icon-sort-icon"></i>}</li>
                      )
                    })}
                  </ul>
                </div>

                <div className="tblContent">
                  <ul>
                    {userList?.map((item, index) => {
                      return (
                        <li key={index.toString()} onClick={() => { 
                          navigate('/admin/customer/customerdetails') 
                          props.setBook(item)
                          }} >
                          <div><p>{index + 1}</p></div>
                          <div><p>{item.sName} </p></div>
                          <div><p>{item.sAuthor}</p></div>
                          <div><p>{item.nPrice}</p></div>
                          <div><p>{item.nStock}</p></div>
                          <div><p>{item.oUserId.sFirstName} {item.oUserId.sLastName}</p></div>   
                        </li>
                      )
                    })}
                  </ul>
                  <ul>
                    {userList.length === 0 &&
                      <div className='notAnytribe'>
                        <div>
                          <i className="icon icon-No-records_empty-state" />
                          <p>{strings['NO_RECORDS_FOUND']}</p>
                        </div>
                      </div>
                    }
                  </ul>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>

      <ModalPopup
        showModal={showStatusModal}
        closeButton={true}
        onHide={() => { setShowStatusModal(false); }}
        className="customerModal"
      >
        <h6><i className='icon icon-user-avatar-icon' /> {statusValue?.value ? strings['ENABLE'] : strings['DISABLE']}</h6>
        <p>{statusValue?.value ? `${strings['ARE_YOU_SURE_ENABLE'] + ' ' + customerDetail?.fullNmae} ?` : `${strings['ARE_YOU_SURE_DISABLE'] + ' ' + customerDetail?.fullNmae} ?`}</p>
        <div className="footerbtnInline">
          <CustomButton type="button" title={strings["YES"]} onClick={() => {
            onProcced();
          }} />
          <CustomButton type="button" title={strings["NO"]} onClick={() => {
            setShowStatusModal(false)
          }} />
        </div>
      </ModalPopup>

      <ModalPopup
        showModal={showDeleteModal}
        closeButton={true}
        onHide={() => { setShowDeleteModal(false); }}
        className="logoutModal"
      >
        <h6><i className='icon icon-Delete-icon' /> {strings['DELETE']}</h6>
        <p>{strings['DELETE_THIS_PARTNER']}</p>
        <div className="btnInline">
          <CustomButton type="button" title={strings["YES"]} onClick={() => {
            onPressDeleteCustomer()
          }} />
          <CustomButton type="button" title={strings["NO"]} onClick={() => {
            setShowDeleteModal(false)
          }} />
        </div>
      </ModalPopup>

    </>
  );
};

const mapStateToProps = (state) => {return {
  books:state.bookReducer.book
}};

const mapDispatchToProps = {
  showToast,setBook
};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(Customer));