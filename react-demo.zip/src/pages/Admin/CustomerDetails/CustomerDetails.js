import React, { useEffect, useState } from "react";
import { multilanguage } from "redux-multilanguage";
import { useNavigate } from "react-router-dom";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { connect } from "react-redux";

import useWindowDimension from "../../../hooks/useWindowDimension";
import "./CustomerDetails.scss";
import CustomButton from "../../../assets/components/UI/CustomButton/CustomButton";

const CustomerDetails = (props) => {
  let { strings,books } = props;
  const navigate = useNavigate();
  const dimensions = useWindowDimension();
  const [headerHeight, setHeaderHeight] = useState(0);
  const [startDate, setStartDate] = useState(new Date());
  const [certificateStartDate, setCertificateStartDate] = useState(new Date());
  const downloadMedia = link => {
    fetch(link)
      .then(response => {
        let filename = response.url.split('/')
        response.blob().then(blob => {
          let url = window.URL.createObjectURL(blob);
          let a = document.createElement('a');
          a.href = url;
          a.download = filename[filename.length - 1];
          a.click();
        });
      });
  }

  const MyProgressDateFilter = ({ value, onClick }) => {
    return (
      <button type="button" className="custom-date-input" onClick={onClick}>
        {value} <i className='icon icon-Calendar-icon' />
      </button>
    )
  };

  const onChangeMyProgressDate = dates => {
    setStartDate(dates);
  };

  const MyCertificatesDateFilter = ({ value, onClick }) => {
    return (
      <button type="button" className="custom-date-input" onClick={onClick}>
        {value} <i className='icon icon-Calendar-icon' />
      </button>
    )
  };

  const onChangeMyCertificatesDate = dates => {
    setCertificateStartDate(dates);
  };

  useEffect(() => {
    setHeaderHeight(document.getElementsByClassName("adminHeader")[0]?.offsetHeight);
  }, []);




  return (
    <>
      <div className="customerDetailsPage" style={{ paddingTop: headerHeight }}>
        <div className="customerDetailsBack" style={{ height: dimensions.height - headerHeight + "px" }}>
          <div className="customerDetailsCenter">
            <div className="pageTitleRow">
              <div className="leftPart">
                <button className="backbtn" onClick={() => navigate(-1)}><i className="icon-Left-arrow"></i></button>
                <div className="userName">{books.sName}</div>
              </div>
              <div className="rightPart">
                <CustomButton className='delete' title={"Purchase"} />
              </div>
            </div>
            <div className="userListBox">
              <ul>
                    <li key="0">
                      <div className="headingName">Owner Name</div>
                      <div className="listName">{books.oUserId.sFirstName+" "+books.oUserId.sLastName}</div>
                    </li>
                    <li key="1">
                      <div className="headingName">price</div>
                      <div className="listName">{books.nPrice}</div>
                    </li>
                    <li key="2">
                      <div className="headingName">Author</div>
                      <div className="listName">{books.sAuthor}</div>
                    </li>
                    <li key="3">
                      <div className="headingName">stock</div>
                      <div className="listName">{books.nStock}</div>
                    </li>
                
              </ul>
            </div>
            
          </div>
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state) => { 
  return {
    books:state.bookReducer.book
  } };

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(CustomerDetails));