import React from 'react';
import { multilanguage } from 'redux-multilanguage';

const PageNotFound = ({ strings }) => {
    return (
        <div>Page not found</div>
    );
};

export default multilanguage(PageNotFound);
