const Constant = {
    REGEX: {
        EMAIL: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        SPECIALCHARACTERS: /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/,
        UPPERCASELOWERCASE: /[a-z].*[A-Z]|[A-Z].*[a-z]/,
        NUMBER: /^[0-9]*$/,
        NAME: /^[a-zA-Z\-\s\u00C0-\u00FF]*$/,
        LINKEDIN: /^https:\/\/[a-z]{2,3}\.linkedin\.com\/.*$/gim,
        UK_POSTCODE: /^([A-Za-z][A-Ha-hJ-Yj-y]?[0-9][A-Za-z0-9]? ?[0-9][A-Za-z]{2}|[Gg][Ii][Rr] ?0[Aa]{2})$/,
        NUMBER_PASS: /[0-9]/,
        NUMBER_DECIMAL: /^\d*\.?\d*$/,
        URL: /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[A-Za-z]{2,4}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/
    },
    IMAGESURL: {
        LOGO: 'https://res.cloudinary.com/zudu/image/upload/v1653651259/Earth-Rising/Project-images/Logo.svg',
    }
};
export default Constant;
