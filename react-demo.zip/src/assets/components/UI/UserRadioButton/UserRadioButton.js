import React, { useEffect, useState } from "react";
import "./UserRadioButton.scss";

const UserRadioButton = (props) => {
    let { children } = props;

    const [checked, setChecked] = useState(false)

    useEffect(() => {
        props.isSelected && setChecked(props.isSelected)
    }, [])

    const checkChange = (e) => {
        props.changed(e.target)
    }

    return (
        <div className="UserRadioButton">
            <input type="radio" onChange={checkChange} id={props.id} name={props.name} value={props.value} checked={props.isSelected} disabled={props.disabled} />
            <label htmlFor={props.id}>
                {props.isSelected ? <i className="icon icon-Checkbox_checked" /> : null}
                <div>
                    <i className={props.iconName} />
                    <p>{props.label}</p>
                </div>
            </label>
        </div>

    );
}

export default UserRadioButton;