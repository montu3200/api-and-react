import React, { useState, useEffect } from "react";
import './DropDownCheckBox.scss';

const DropDownCheckBox = (props) => {
    let { labelTitle, id, onCheckedChange, register, name, disabled, showSQM } = props;
    const [checked, setChecked] = useState(!!props.checked)

    useEffect(() => {
        setChecked(props.checked)
    }, [props.checked])

    const onChecked = (e) => {
        setChecked(e.target.checked)
        onCheckedChange && onCheckedChange(e.target.checked)
    }

    return (
        <div className="dropDownCheckbox">
            <div className="checkInline">
                <input type="checkbox" ref={register} disabled={disabled} name={name} value={labelTitle} id={id} className='checkbox' checked={checked} onChange={onChecked} />
                <label className={checked ? 'checked' : ''} id="checkLabel" htmlFor={id}>{labelTitle} {showSQM && <span>sq. m.</span>}</label>
                {checked ? <i className='icon icon-Checkbox_checked' /> : <i className='icon icon-Checkbox_blank' />}
            </div>
        </div>
    )
}

DropDownCheckBox.defaultProps = {
    id: '',
    checked: false,
    labelTitle: '',
    showSQM: false,
}

export default DropDownCheckBox;