import React, { useEffect, useState } from 'react';
import { multilanguage } from "redux-multilanguage";
import { Controller } from 'react-hook-form';
import { connect } from 'react-redux';

import HookForm from '../../HookForm/HookForm';
import TextField from '../TextField/TextField';
import FileUpload from '../FileUpload/FileUpload';
import CustomButton from '../CustomButton/CustomButton';
import CustomDropdown from '../CustomDropdown/CustomDropdown';

import Constant from '../../../../state/utils/constant';
import { showToast } from "../../../../redux/actions/toastAction";
import useWindowDimension from '../../../../hooks/useWindowDimension';

import "./CreateTribe.scss";

const businessCategoryData = [
  {
    id: '1',
    title: 'Eco products',
    value: 'Eco products',
  },
  {
    id: '2',
    title: 'Endorsed green energy',
    value: 'Endorsed green energy',
  },
  {
    id: '3',
    title: 'Ecological',
    value: 'Ecological',
  },
  {
    id: '4',
    title: 'Conservation body membership',
    value: 'Conservation body membership',
  },
]

const CreateTribe = (props) => {
  let { strings, onCancel, showToast } = props;
  const [busy, setBusy] = useState(false);
  const [createTribe, setCreateTribeForm] = useState();
  const [businessCategory, setBusinessCategory] = useState(null);
  const [profile, setProfile] = useState(null);

  const onTribeImageChange = async (acceptedFiles) => {
    const reader = new FileReader();
    reader.addEventListener("load", (event) => {
      setProfile(event.target.result);
    });
    reader.readAsDataURL(acceptedFiles[0]);
  };

  const onFormSubmit = (data) => {
    setBusy(true);
    showToast({
      message: "Tribe “Reusable Bread Bag” has been created successfully.",
      type: "success",
    });
    setTimeout(() => {
      onCancel();
      setBusy(false);
    }, 1000);
  };

  const tribesFormData = {
    tribesName: {
      name: "tribesName",
      validate: {
        required: {
          value: true,
          message: strings["TRIBE_NAME_IS_REQUIRED"],
        },
        pattern: {
          value: Constant.REGEX.NAME,
          message: strings["ONLY_ALPHABETICAL_CHARACTERS"],
        },
      },
    },
    businessCategory: {
      name: 'businessCategory',
      validate: {
        required: {
          value: true,
        }
      }
    },
    description: {
      name: 'description',
      validate: {
        required: {
          value: true,
          message: strings["DESCRIPTION_IS_REQUIRED"],
        },
      },
    },
  };


  return (
    <HookForm
      defaultForm={{}}
      init={(form) => setCreateTribeForm(createTribe)}
      onSubmit={(e) => onFormSubmit(e)}
    >
      {(formMethod) => {
        return (<>
          <Controller
            defaultValue=""
            name="image"
            control={formMethod.control}
            render={({ field: { onChange, value } }) => (
              <FileUpload
                onDrop={(acceptedFiles) => {
                  onChange(acceptedFiles);
                  onTribeImageChange(acceptedFiles);
                }}
                accept="image/jpeg,image/jpg,image/png"
              >
                <div className="profileRound">
                  {profile ? (
                    <div className="uploadedImg">
                      <img src={profile} alt="" />
                    </div>
                  ) : (
                    <>
                      <div className="uploadedImg">
                        {profile ? (
                          <img src={profile} alt="" />
                        ) : (
                          <div className="uploadLogo">
                            <div>
                              <i className="icon icon-add-circle-icon" />
                              <p>{strings["UPLOAD_TRIBE_PROFILE_PICTURE"]}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </>
                  )}
                </div>
              </FileUpload>
            )}
          />
          <TextField
            formMethod={formMethod}
            rules={tribesFormData.tribesName.validate}
            name={tribesFormData.tribesName.name}
            errors={formMethod?.formState?.errors}
            autoFocus={true}
            type="text"
            lableTitle={strings['TRIBE_NAME']}
            placeholder={strings["ENTER_TRIBE_NAME"]}
            isReqired={true}
          />
          <Controller
            render={({
              field: { onChange }
            }) => (
              <CustomDropdown
                lableTitle={strings['BUSINESS_CATEGORY']}
                isReqired={true}
                placeholder={strings['SELECT']}
                autoClose={"outside"}
                dropDownItems={businessCategoryData}
                align={"end"}
                selectedValue={businessCategory}
                onSelect={(evt) => {
                  onChange(evt);
                  setBusinessCategory(evt);
                }}
              />
            )}
            control={formMethod.control}
            name={tribesFormData.businessCategory.name}
            rules={tribesFormData.businessCategory.validate}
            defaultValue={formMethod.watch(
              tribesFormData.businessCategory.name
            )}
          />
          <TextField
            formMethod={formMethod}
            rules={tribesFormData.description.validate}
            name={tribesFormData.description.name}
            errors={formMethod?.formState?.errors}
            autoFocus={false}
            maxLength={500}
            textarea='textarea'
            lableTitle={strings['DESCRIPTION']}
            placeholder={strings["WRITE_HERE"]}
            isReqired={true}
          >
            <p className="countValue">
              {formMethod?.watch(
                tribesFormData.description.name
              )
                ? formMethod?.watch(
                  tribesFormData.description.name
                )?.length
                : 0}
              /500
            </p>
          </TextField>
          <div className="bottomButton">
            <CustomButton
              title={strings["CREATE_A_TRIBE"]}
              disabled={!formMethod?.formState.isValid || !profile}
            />
            <CustomButton
              type="button"
              title={strings["CANCEL"]}
              className='cancel'
              onClick={onCancel}
            />
          </div>
        </>
        );
      }}
    </HookForm>

  );
}

const mapStateToProps = (state) => { return {}; };

const mapDispatchToProps = {
  showToast,
};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(CreateTribe));