import React, { useEffect, useState } from 'react';
import { multilanguage } from "redux-multilanguage";
import { connect } from "react-redux";

import HookForm from '../../HookForm/HookForm';
import SearchBox from '../SearchBox/SearchBox';
import TextField from '../TextField/TextField';
import CustomButton from '../CustomButton/CustomButton';

import Constant from '../../../../state/utils/constant';
import { showToast } from "../../../../redux/actions/toastAction";
import useWindowDimension from '../../../../hooks/useWindowDimension';

import './OtherFactorsDetails.scss';

const OtherFactorsList = [
  {
    id: 1,
    TariffName: 'UK Average',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 2,
    TariffName: 'Leccy',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 3,
    TariffName: 'Angelic energy',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 4,
    TariffName: 'Lumo',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 5,
    TariffName: 'Atlantic SSE',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 6,
    TariffName: 'M&S Energy',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 7,
    TariffName: 'Beam Energy',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 8,
    TariffName: 'Nabuh Energy',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 9,
    TariffName: 'Boost',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 10,
    TariffName: 'npower',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  }, {
    id: 11,
    TariffName: 'Breeze',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 12,
    TariffName: 'n power northern',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 13,
    TariffName: 'Bristol Energy',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 14,
    fullNmae: 'n power yorkshire',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 15,
    TariffName: 'British Gas',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },
  {
    id: 16,
    TariffName: 'octopus energy',
    fieldValue1: '',
    fieldValue2: '',
    fieldValue3: ''
  },

]
const OtherFactorsDetails = (props) => {
  let { strings, showToast } = props;
  const dimensions = useWindowDimension();
  const [busy, setBusy] = useState(false);
  const [headerHeight, setHeaderHeight] = useState(0);
  const [pageTitleHeight, setPageTitleHeight] = useState(0);
  const [tabNavbarHeight, setTabNavbarHeight] = useState(0);
  const [searchRowHeight, setSearchRowHeight] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [otherUpdate, setOtherUpdate] = useState(false);
  const [otherUpdateOne, setOtherUpdateOne] = useState(false);
  const [otherUpdateTwo, setOtherUpdateTwo] = useState(false);
  const [otherFactorsform, setOtherFactorsForm] = useState();
  const [otherFactorsList, setOtherFactorsList] = useState(OtherFactorsList);

  useEffect(() => {
    setHeaderHeight(document.getElementsByClassName("adminHeader")[0]?.offsetHeight);
    setPageTitleHeight(document.getElementsByClassName("title")[0]?.offsetHeight);
    setTabNavbarHeight(document.getElementsByClassName("navCustomTab")[0]?.offsetHeight);
    setSearchRowHeight(document.getElementsByClassName("searchRow")[0]?.offsetHeight);
  }, []);
  const otherFactorsForm = {
    litres: {
      name: 'litres',
      validate: {
        required: {
          value: false,
        },
        pattern: {
          value: Constant.REGEX.NUMBER_DECIMAL,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    },
    kWh: {
      name: 'kWh',
      validate: {
        required: {
          value: false,
        },
        pattern: {
          value: Constant.REGEX.NUMBER_DECIMAL,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    },
    CO2kWh: {
      name: 'CO2kWh',
      validate: {
        required: {
          value: false,
        },
        pattern: {
          value: Constant.REGEX.NUMBER_DECIMAL,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    }
  };
  const onFormSubmit = (data) => {
    setBusy(true);
    showToast({
      message: "Details have been updated successfully.",
      type: "success",
    });
    setTimeout(() => {
      setBusy(false);
    }, 1000);
  };

  return (
    <>
      <HookForm
        defaultForm={{}}
        init={(form) => setOtherFactorsForm(otherFactorsform)}
        onSubmit={(e) => onFormSubmit(e)}
      >
        {(formMethod) => {
          return (<>
            <div className="searchRow">
              <SearchBox
                placeholder={strings["SEARCH_NAME_EMAIL"]}
                value={searchText}
                onClear={() => {
                  setSearchText("");
                }}
                onSearch={(e) => {
                  setSearchText(e);
                }}
              />
              <div className="rightSideBtn">
                <CustomButton className="saveUpdate" disabled={((otherUpdate || otherUpdateOne || otherUpdateTwo) && formMethod?.formState?.isValid) ? false : true} title={strings["SAVE_UPDATE_DETAILS"]} />
              </div>
            </div>
            <div className="otherFactorsList" style={{ maxHeight: (dimensions.height - headerHeight - pageTitleHeight - tabNavbarHeight - searchRowHeight - 45) }}>
              {otherFactorsList?.map((item, index) => {
                return (
                  <div className="listBox" key={index.toString()}>
                    <div className="listColumn">{item.TariffName}</div>
                    <div className="listColumn">
                      <TextField
                        formMethod={formMethod}
                        rules={otherFactorsForm.litres.validate}
                        name={`${otherFactorsForm.litres.name}${index}`}
                        errors={formMethod?.formState?.errors}
                        autoFocus={false}
                        type="text"
                        placeholder='0'
                        isReqired={true}
                        valueProp={item.fieldValue1}
                        maxLength={5}
                        onChange={(e) => {
                          if (e.target.value !== '') {
                            setOtherUpdate(true)
                          }
                          setOtherFactorsList(otherFactorsList.map((eitem, eindex) => {
                            if (index === eindex) {
                              eitem.fieldValue1 = e.target.value;
                            }
                            return eitem
                          }))
                        }}
                      />
                    </div>
                    <div className="listColumn">
                      <TextField
                        formMethod={formMethod}
                        rules={otherFactorsForm.kWh.validate}
                        name={`${otherFactorsForm.kWh.name}${index}`}
                        errors={formMethod?.formState?.errors}
                        autoFocus={false}
                        type="text"
                        placeholder='0'
                        isReqired={true}
                        valueProp={item.fieldValue2}
                        maxLength={5}
                        onChange={(e) => {
                          if (e.target.value !== '') {
                            setOtherUpdateOne(true)
                          }
                          setOtherFactorsList(otherFactorsList.map((eitem, eindex) => {
                            if (index === eindex) {
                              eitem.fieldValue2 = e.target.value;
                            }
                            return eitem
                          }))
                        }}
                      />
                    </div>
                    <div className="listColumn">
                      <TextField
                        formMethod={formMethod}
                        rules={otherFactorsForm.CO2kWh.validate}
                        name={`${otherFactorsForm.CO2kWh.name}${index}`}
                        errors={formMethod?.formState?.errors}
                        autoFocus={false}
                        type="text"
                        placeholder='0'
                        maxLength={10}
                        isReqired={true}
                        valueProp={item.fieldValue3}
                        onChange={(e) => {
                          if (e.target.value !== '') {
                            setOtherUpdateTwo(true)
                          }
                          // onOtherFactorSaveUpdate()
                          setOtherFactorsList(otherFactorsList.map((eitem, eindex) => {
                            if (index === eindex) {
                              eitem.fieldValue3 = e.target.value;
                            }
                            return eitem
                          }))
                        }}
                      />
                    </div>
                  </div>
                )
              })}
            </div>
          </>
          );
        }}
      </HookForm>
    </>
  )
}
const mapStateToProps = (state) => { return {}; };

const mapDispatchToProps = {
  showToast
};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(OtherFactorsDetails));