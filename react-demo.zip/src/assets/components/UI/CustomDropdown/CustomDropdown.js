import React from 'react';
import PropTypes from 'prop-types';
import DropdownButton from 'react-bootstrap/DropdownButton'
import Dropdown from 'react-bootstrap/Dropdown'
import './CustomDropdown.scss';

const CustomDropdown = (props) => {
    let { lableTitle, isReqired, customeStyle, selectedValue, dropDownItems = [], placeholder, onSelect } = props;

    const getTitle = () => {
        if (selectedValue && selectedValue.id) {
            const item = dropDownItems.find(i => i.id === selectedValue.id)
            return (item && item.value) || placeholder
        } else {
            return placeholder
        }
    }

    return (
        <div className="customDropdown">
            <label className="label">{lableTitle}{isReqired && <span>*</span>}</label>
            <DropdownButton
                key={selectedValue?.id}
                id={`dropdown-variants-${selectedValue?.id}`}
                title={getTitle()}
                onSelect={evt => onSelect(dropDownItems.find(i => i.id === evt))}
                className={selectedValue ? "selected" : ""}
            >
                <div className="dropdownData">
                    {dropDownItems.map((item, index) => <Dropdown.Item key={index.toString()} eventKey={item.id} >{item.value}</Dropdown.Item>)}
                </div>
            </DropdownButton>
        </div>
    )
}

CustomDropdown.propTypes = {
    onClick: PropTypes.func
};

export default CustomDropdown;
