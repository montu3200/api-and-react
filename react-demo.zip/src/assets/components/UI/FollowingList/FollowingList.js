import React, { useEffect, useState } from 'react';
import { multilanguage } from "redux-multilanguage";
import { connect } from "react-redux";

import SearchBox from '../SearchBox/SearchBox';
import CustomButton from '../CustomButton/CustomButton';

import useWindowDimension from '../../../../hooks/useWindowDimension';
import './FollowingList.scss';
import { useNavigate } from 'react-router-dom';

const follwingList = [
  {
    id: 1,
    followingImage: 'https://res.cloudinary.com/zudu/image/upload/v1657089498/Earth-Rising/Static-images/folllowing.png',
    followingName: 'Ade. Plagusa.',
    createdBy: 'John Mark',
    followStatus: true,
    requestStatus: true,
  },
  {
    id: 2,
    followingImage: 'https://res.cloudinary.com/zudu/image/upload/v1657089498/Earth-Rising/Static-images/folllowing.png',
    followingName: 'Ade. Plagusa.',
    createdBy: 'John Mark',
    followStatus: true,
    requestStatus: true,
  },
  {
    id: 3,
    followingImage: 'https://res.cloudinary.com/zudu/image/upload/v1657089498/Earth-Rising/Static-images/folllowing.png',
    followingName: 'Ade. Plagusa.',
    createdBy: 'John Mark',
    followStatus: true,
    requestStatus: true,
  },
  {
    id: 4,
    followingImage: 'https://res.cloudinary.com/zudu/image/upload/v1657089498/Earth-Rising/Static-images/folllowing.png',
    followingName: 'Ade. Plagusa.',
    createdBy: 'John Mark',
    followStatus: true,
    requestStatus: true,
  },
  {
    id: 5,
    followingImage: 'https://res.cloudinary.com/zudu/image/upload/v1657089498/Earth-Rising/Static-images/folllowing.png',
    followingName: 'Ade. Plagusa.',
    createdBy: 'John Mark',
    followStatus: false,
    requestStatus: false,
  }

]
const FollowingList = (props) => {
  let { strings } = props;
  const navigate = useNavigate();
  const dimensions = useWindowDimension();
  const [headerHeight, setHeaderHeight] = useState(0);
  const [pageTitleHeight, setPageTitleHeight] = useState(0);
  const [tabNavbarHeight, setTabNavbarHeight] = useState(0);
  const [searchRowHeight, setSearchRowHeight] = useState(0);
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    setHeaderHeight(document.getElementsByClassName("userHeader")[0]?.offsetHeight);
    setPageTitleHeight(document.getElementsByClassName("pageTitleRow")[0]?.offsetHeight);
    setTabNavbarHeight(document.getElementsByClassName("navCustomTab")[0]?.offsetHeight);
    setSearchRowHeight(document.getElementsByClassName("searchRow")[0]?.offsetHeight);
  }, []);

  return (
    <>
      <div className="searchRow">
        <SearchBox
          placeholder={strings['SEARCH_TRIBE_BY_NAME']}
          value={searchText}
          onClear={() => {
            setSearchText("");
          }}
          onSearch={(e) => {
            setSearchText(e);
          }}
        />
      </div>
      <div className="follwingList" style={{ maxHeight: (dimensions.height - headerHeight - pageTitleHeight - tabNavbarHeight - searchRowHeight - 45) }}>
        {follwingList?.map((item, index) => {
          return (
            <div key={index.toString()} className="listBox" onClick={() => { navigate('/managetribes/viewfollowingtribe') }}>
              <div className={item.followStatus === true ? "listColumn revoke_request_hover" : "listColumn"}>
                <img src={item.followingImage} alt='' />
                <div className='nameMain'>
                  <h6>{item.followingName}</h6>
                  <p>{strings["CREATED_BY"]} {item.createdBy}</p>
                </div>
                <div className="btnarea">
                  {item.followStatus ?
                    <CustomButton onClick={(e) => e.stopPropagation()}
                      title={strings["REVOKE_REQUEST"]}
                    />
                    :
                    <CustomButton onClick={(e) => e.stopPropagation()}
                      title={strings["FOLLOW"]}
                    />
                  }
                  {item.requestStatus &&
                    <p>{strings['REQUEST_SENT']}</p>
                  }
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </>
  )
}
const mapStateToProps = (state) => { return {}; };

const mapDispatchToProps = {
};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(FollowingList));