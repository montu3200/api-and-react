import React, { useEffect, useState } from 'react';
import { multilanguage } from "redux-multilanguage";
import { connect } from "react-redux";

import SearchBox from '../SearchBox/SearchBox';
import TextField from '../TextField/TextField';
import HookForm from '../../HookForm/HookForm';
import ModalPopup from '../ModalPopup/ModalPopup';
import CustomButton from '../CustomButton/CustomButton';

import Constant from '../../../../state/utils/constant';
import { showToast } from "../../../../redux/actions/toastAction";
import useWindowDimension from '../../../../hooks/useWindowDimension';

import './ElectrictyFactorsDetails.scss';

const ElectricityFactorsList = [
  {
    id: 1,
    TariffName: 'UK Average',
    fieldValue: ''
  },
  {
    id: 2,
    TariffName: 'Leccy',
    fieldValue: ''
  },
  {
    id: 3,
    TariffName: 'Angelic energy',
    fieldValue: ''
  },
  {
    id: 4,
    TariffName: 'Lumo',
    fieldValue: ''
  },
  {
    id: 5,
    TariffName: 'Atlantic SSE',
    fieldValue: ''
  },
  {
    id: 6,
    TariffName: 'M&S Energy',
    fieldValue: ''
  },
  {
    id: 7,
    TariffName: 'Beam Energy',
    fieldValue: ''
  },
  {
    id: 8,
    TariffName: 'Nabuh Energy',
    fieldValue: ''
  },
  {
    id: 9,
    TariffName: 'Boost',
    fieldValue: ''
  },
  {
    id: 10,
    TariffName: 'npower',
    fieldValue: ''
  }, {
    id: 11,
    TariffName: 'Breeze',
    fieldValue: ''
  },
  {
    id: 12,
    TariffName: 'n power northern',
    fieldValue: ''
  },
  {
    id: 13,
    TariffName: 'Bristol Energy',
    fieldValue: ''
  },
  {
    id: 14,
    fullNmae: 'n power yorkshire',
    fieldValue: ''
  },
  {
    id: 15,
    TariffName: 'British Gas',
    fieldValue: ''
  },
  {
    id: 16,
    TariffName: 'octopus energy',
    fieldValue: ''
  },

]
const ElectrictyFactorsDetails = (props) => {
  let { strings, showToast, onAddTariff } = props;
  const dimensions = useWindowDimension();
  const [busy, setBusy] = useState(false);
  const [headerHeight, setHeaderHeight] = useState(0);
  const [pageTitleHeight, setPageTitleHeight] = useState(0);
  const [tabNavbarHeight, setTabNavbarHeight] = useState(0);
  const [searchRowHeight, setSearchRowHeight] = useState(0);
  const [listHeadingHeight, setListHeadingHeight] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [gramsCarbonKWhform, setGramsCarbonKWhForm] = useState();
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [electricityFactorsList, setElectricityFactorsList] = useState(ElectricityFactorsList);


  const onFormSubmit = (data) => {
    setBusy(true);
    showToast({
      message: "Details have been updated successfully.",
      type: "success",
    });
    setTimeout(() => {
      setBusy(false);
    }, 1000);
  };
  const onPressDeleteCustomer = async () => {
    setShowDeleteModal(false);
    props.showToast({
      message: 'Details have been deleted successfully.',
      type: "success",
    });
  };

  useEffect(() => {
    setHeaderHeight(document.getElementsByClassName("adminHeader")[0]?.offsetHeight);
    setPageTitleHeight(document.getElementsByClassName("title")[0]?.offsetHeight);
    setTabNavbarHeight(document.getElementsByClassName("navCustomTab")[0]?.offsetHeight);
    setSearchRowHeight(document.getElementsByClassName("searchRow")[0]?.offsetHeight);
    setListHeadingHeight(document.getElementsByClassName("listHeading")[0]?.offsetHeight);
  }, []);

  const electricityFactorsForm = {
    gramsCarbonDioxide: {
      name: 'gramsCarbonDioxide',
      validate: {
        required: {
          value: false,
        },
        pattern: {
          value: Constant.REGEX.NUMBER_DECIMAL,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    }
  };
  return (
    <>
      <HookForm
        defaultForm={{}}
        init={(form) => setGramsCarbonKWhForm(gramsCarbonKWhform)}
        onSubmit={(e) => onFormSubmit(e)}
      >
        {(formMethod) => {
          return (<>
            <div className="searchRow">
              <SearchBox
                placeholder={strings["SEARCH_NAME_EMAIL"]}
                value={searchText}
                onClear={() => {
                  setSearchText("");
                }}
                onSearch={(e) => {
                  setSearchText(e);
                }}
              />
              <div className="rightSideBtn">
                <CustomButton onClick={onAddTariff} type="button" title={strings["ADD_TARIFF"]} />
                <CustomButton className="saveUpdate" disabled={electricityFactorsList.some(item => item.fieldValue !== '') ? electricityFactorsList.some((item, index) => formMethod.formState.errors[`gramsCarbonDioxide${index}`]) ? true : false : true} title={strings["SAVE_UPDATE_DETAILS"]} />
              </div>
            </div>
            <div className="listHeading">
              <div className="headingBox">
                <div className="tariffNameLeft">Tariff Name</div>
                <div className="gramsCarbonDioxideRight">Grams carbon dioxide per kWh</div>
              </div>
              <div className="headingBox">
                <div className="tariffNameLeft">Tariff Name</div>
                <div className="gramsCarbonDioxideRight">Grams carbon dioxide per kWh</div>
              </div>
            </div>
            <div className="electricityFactorsList" style={{ maxHeight: (dimensions.height - headerHeight - pageTitleHeight - tabNavbarHeight - searchRowHeight - listHeadingHeight - 45) }}>
              {electricityFactorsList?.map((item, index) => {
                return (
                  <div className="listBox" key={index.toString()}>
                    <div className="listColumn">{item.TariffName}</div>
                    <div className="listColumn">
                      <TextField
                        formMethod={formMethod}
                        rules={electricityFactorsForm.gramsCarbonDioxide.validate}
                        name={`${electricityFactorsForm.gramsCarbonDioxide.name}${index}`}
                        errors={formMethod?.formState?.errors}
                        autoFocus={false}
                        type="text"
                        placeholder='0'
                        maxLength={5}
                        isReqired={true}
                        valueProp={item.fieldValue}
                        onChange={(e) => {
                          setElectricityFactorsList(electricityFactorsList.map((eitem, eindex) => {
                            console.log("index==>", index);
                            if (index === eindex) {
                              eitem.fieldValue = e.target.value;
                            }
                            return eitem
                          }))
                        }}
                      />

                      <button type="button" onClick={() => {
                        setShowDeleteModal(true);
                      }} className="deleteBtn"><i className="icon-Delete-icon"></i></button>
                    </div>
                  </div>
                )
              })}
            </div>
          </>
          );
        }}
      </HookForm>
      <ModalPopup
        showModal={showDeleteModal}
        closeButton={true}
        onHide={() => { setShowDeleteModal(false); }}
        className="logoutModal"
      >
        <h6><i className='icon icon-Delete-icon' /> {strings['DELETE']}</h6>
        <p>Are you sure, you want to delete this value?</p>
        <div className="btnInline">
          <CustomButton type="button" title={strings["YES"]} onClick={() => {
            onPressDeleteCustomer()
          }} />
          <CustomButton type="button" title={strings["NO"]} onClick={() => {
            setShowDeleteModal(false)
          }} />
        </div>
      </ModalPopup>
    </>
  )
}
const mapStateToProps = (state) => { return {}; };

const mapDispatchToProps = {
  showToast
};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(ElectrictyFactorsDetails));