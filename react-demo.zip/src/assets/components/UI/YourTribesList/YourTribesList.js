import React, { useEffect, useState } from 'react';
import { multilanguage } from "redux-multilanguage";
import { Controller } from 'react-hook-form';
import { Offcanvas } from 'react-bootstrap';
import { connect } from "react-redux";

import HookForm from '../../HookForm/HookForm';
import TextField from '../TextField/TextField';
import SearchBox from '../SearchBox/SearchBox';
import FileUpload from '../FileUpload/FileUpload';
import ModalPopup from '../ModalPopup/ModalPopup';
import CustomButton from '../CustomButton/CustomButton';
import CustomDropdown from '../CustomDropdown/CustomDropdown';

import Constant from '../../../../state/utils/constant';
import { showToast } from "../../../../redux/actions/toastAction";
import useWindowDimension from '../../../../hooks/useWindowDimension';

import './YourTribesList.scss';

const businessCategoryData = [
  {
    id: '1',
    title: 'Eco products',
    value: 'Eco products',
  },
  {
    id: '2',
    title: 'Endorsed green energy',
    value: 'Endorsed green energy',
  },
  {
    id: '3',
    title: 'Ecological',
    value: 'Ecological',
  },
  {
    id: '4',
    title: 'Conservation body membership',
    value: 'Conservation body membership',
  },
]
const YourTribesList = (props) => {
  let { strings, showToast } = props;
  const [busy, setBusy] = useState(false);
  const dimensions = useWindowDimension();
  const [headerHeight, setHeaderHeight] = useState(0);
  const [pageTitleHeight, setPageTitleHeight] = useState(0);
  const [tabNavbarHeight, setTabNavbarHeight] = useState(0);
  const [searchRowHeight, setSearchRowHeight] = useState(0);
  const [headingListHeight, setHeadingListHeight] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [deleteTribeModal, setDeleteTribeModal] = useState(false);
  const [editTribesModal, setEditTribesModal] = useState(false);
  const [tribesForm, setTribesForm] = useState(false);
  const [businessCategory, setBusinessCategory] = useState(null);
  let [profile, setProfile] = useState(null);

  useEffect(() => {
    setHeaderHeight(document.getElementsByClassName("userHeader")[0]?.offsetHeight);
    setPageTitleHeight(document.getElementsByClassName("pageTitleRow")[0]?.offsetHeight);
    setTabNavbarHeight(document.getElementsByClassName("navCustomTab")[0]?.offsetHeight);
    setSearchRowHeight(document.getElementsByClassName("searchRow")[0]?.offsetHeight);
    setHeadingListHeight(document.getElementsByClassName("headerList")[0]?.offsetHeight);

  }, []);


  const onPressConfirm = () => {
    setDeleteTribeModal(false);
    showToast({
      message: 'Tribe “Reusable Bread Bag” has been successfully deleted.',
      type: "success",
    });
  };
  const onTribesLogoChange = async (acceptedFiles) => {
    const reader = new FileReader();
    reader.addEventListener("load", (event) => {
      setProfile(event.target.result);
    });
    reader.readAsDataURL(acceptedFiles[0]);
  };
  const onFormSubmit = (data) => {
    setBusy(true);
    showToast({
      message: "Tribe “Reusable Bread Bag” details have been successfully updated.",
      type: "success",
    });
    setTimeout(() => {
      setEditTribesModal(false)
      setBusy(false);
    }, 1000);
  };

  const tribesFormData = {
    tribesName: {
      name: "tribesName",
      validate: {
        required: {
          value: true,
        },
        pattern: {
          value: Constant.REGEX.NAME,
          message: strings["ONLY_ALPHABETICAL_CHARACTERS"],
        },
      },
    },
    businessCategory: {
      name: 'businessCategory',
      validate: {
        required: {
          value: true,
        }
      }
    },
    description: {
      name: 'description',
      validate: {
        required: {
          value: true,
        },
      },
    },
  };

  const tribeNameHeader = [
    { id: 1, title: strings['TRIBE_NAME'], sorting: true },
    { id: 2, title: strings['NO_OF_MEMBERS'], sorting: true },
    { id: 3, title: strings['PENDING_REQUESTS'], sorting: false },
    { id: 4, title: strings['ACTION'], sorting: false },
  ]

  const tribeNameList = [
    {
      id: 1,
      tribeName: 'Ade. Plagusa. ',
      noMembers: '12',
      pendingRequests: '1'
    },
    {
      id: 2,
      tribeName: 'Reusable bag',
      noMembers: '12',
      pendingRequests: '5'
    },
    {
      id: 3,
      tribeName: 'Ade. Plagusa 123',
      noMembers: '12',
      pendingRequests: '10'
    }
  ]
  return (
    <>
      <div className="searchRow">
        <SearchBox
          placeholder={strings['SEARCH_TRIBE_BY_NAME']}
          value={searchText}
          onClear={() => {
            setSearchText("");
          }}
          onSearch={(e) => {
            setSearchText(e);
          }}
        />
      </div>
      <div className="yourTribesBoxes">
        <ul className="headerList">
          {tribeNameHeader.map((item, index) => {
            return (
              <li key={index.toString()}>{(item.title)}{(item.sorting === true && tribeNameList.length !== 0) && <i className="icon icon-sort-icon"></i>}</li>
            )
          })}
        </ul>
        <ul className="yourtribes-table" style={{ maxHeight: (dimensions.height - headerHeight - pageTitleHeight - tabNavbarHeight - searchRowHeight - headingListHeight - 110) }}>
          {tribeNameList.length === 0 &&
            <div className='notAnytribe'>
              <div>
                <i className="icon icon-No-records_empty-state" />
                <p>{strings['NOT_CREATED_ANY_TRIBE_YET']}</p>
              </div>
            </div>
          }
          {tribeNameList.map((item, index) => {
            return (
              <li key={index.toString()}>
                <p className="tribeName">
                  {item.tribeName}
                </p>
                <p className="noMembers">
                  {item.noMembers}
                </p>
                <p className="noMembers">
                  {item.pendingRequests}
                </p>
                <div className="actions">
                  <i className='icon icon-edit-profile-icon' onClick={() => {
                    setEditTribesModal(true)
                  }} />
                  <i className='icon icon-Delete-icon' onClick={() => {
                    setDeleteTribeModal(true)
                  }} />
                </div>
              </li>
            )
          })}
        </ul>
      </div>

      <Offcanvas className='tribeCanvas' show={editTribesModal} onHide={() => { setEditTribesModal(false) }} {...props} placement='end'>

        <Offcanvas.Header>
          <Offcanvas.Title> {strings['EDIT_TRIBE_DETAILS']} </Offcanvas.Title>
        </Offcanvas.Header>

        <Offcanvas.Body>
          <HookForm
            defaultForm={{}}
            init={(form) => setTribesForm(tribesForm)}
            onSubmit={(e) => onFormSubmit(e)}
          >
            {(formMethod) => {
              return (
                <>
                  <div className="formScroll" style={{ height: dimensions.height - 174 + "px", }}>
                    <Controller
                      defaultValue=""
                      name="image"
                      control={formMethod.control}
                      render={({ field: { onChange, value } }) => (
                        <FileUpload
                          onDrop={(acceptedFiles) => {
                            onChange(acceptedFiles);
                            onTribesLogoChange(acceptedFiles);
                          }}
                          accept="image/jpeg,image/jpg,image/png"
                        >
                          <div className="profileRound">
                            {profile ? (
                              <div className="uploadedImg">
                                <img src={profile} alt="" />
                              </div>
                            ) : (
                              <>
                                <div className="uploadedImg">
                                  {profile ? (
                                    <img src={profile} alt="" />
                                  ) : (
                                    <div className="uploadLogo">
                                      <div>
                                        <i className="icon icon-add-circle-icon" />
                                        <p>{strings["UPLOAD_TRIBE_PROFILE_PICTURE"]}</p>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </>
                            )}
                          </div>
                        </FileUpload>
                      )}
                    />
                    <TextField
                      formMethod={formMethod}
                      rules={tribesFormData.tribesName.validate}
                      name={tribesFormData.tribesName.name}
                      errors={formMethod?.formState?.errors}
                      autoFocus={true}
                      type="text"
                      lableTitle={strings['TRIBE_NAME']}
                      placeholder={strings["ENTER_TRIBE_NAME"]}
                      isReqired={true}
                    />
                    <Controller
                      render={({
                        field: { onChange }
                      }) => (
                        <CustomDropdown
                          lableTitle={strings['BUSINESS_CATEGORY']}
                          isReqired={true}
                          placeholder={strings['SELECT_BUSINESS_CATEGORY']}
                          autoClose={"outside"}
                          dropDownItems={businessCategoryData}
                          align={"end"}
                          selectedValue={businessCategory}
                          onSelect={(evt) => {
                            onChange(evt);
                            setBusinessCategory(evt);
                          }}
                        />
                      )}
                      control={formMethod.control}
                      name={tribesFormData.businessCategory.name}
                      rules={tribesFormData.businessCategory.validate}
                      defaultValue={formMethod.watch(
                        tribesFormData.businessCategory.name
                      )}
                    />
                    <TextField
                      formMethod={formMethod}
                      rules={tribesFormData.description.validate}
                      name={tribesFormData.description.name}
                      errors={formMethod?.formState?.errors}
                      autoFocus={false}
                      maxLength={500}
                      textarea='textarea'
                      lableTitle={strings['DESCRIPTION']}
                      placeholder={strings["WRITE_HERE"]}
                      isReqired={true}
                      defaultValue="dgfdg"
                    >
                      <p className="countValue">
                        {formMethod?.watch(
                          tribesFormData.description.name
                        )
                          ? formMethod?.watch(
                            tribesFormData.description.name
                          )?.length
                          : 0}
                        /500
                      </p>
                    </TextField>
                  </div>
                  <div className="bottomButton">
                    <CustomButton
                      title={strings["UPDATE_TRIBE"]}
                      disabled={!formMethod?.formState.isValid || !profile}
                    />
                    <CustomButton
                      type="button"
                      title={strings["CANCEL"]}
                      className='cancel'
                      onClick={() => {
                        setEditTribesModal(false)
                      }}
                    />
                  </div>
                </>
              );
            }}
          </HookForm>
        </Offcanvas.Body>
      </Offcanvas>
      <ModalPopup
        showModal={deleteTribeModal}
        closeButton={true}
        onHide={() => { setDeleteTribeModal(false); }}
        className="deletetribes"
      >
        <h6><i className='icon icon-logout_icon' /> {strings['DELETE_TRIBE']}</h6>
        <p>{strings['DELETE_THIS_TRIBE']}</p>
        <div className="btnInline">
          <CustomButton type="button" title={strings["YES"]} onClick={() => {
            onPressConfirm(false)
          }} />
          <CustomButton type="button" title={strings["NO"]} onClick={() => {
            setDeleteTribeModal(false)
          }} />
        </div>
      </ModalPopup>
    </>
  )
}
const mapStateToProps = (state) => { return {}; };

const mapDispatchToProps = {
  showToast
};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(YourTribesList));