import React, { useEffect, useState } from 'react';
import { Controller } from 'react-hook-form';
import PhoneInput from 'react-phone-input-2';
import { connect } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { multilanguage } from "redux-multilanguage";

import HookForm from '../../HookForm/HookForm';
import TextField from '../TextField/TextField';
import FileUpload from '../FileUpload/FileUpload';
import ModalPopup from '../ModalPopup/ModalPopup';
import CustomButton from '../CustomButton/CustomButton';
import CustomDropdown from '../CustomDropdown/CustomDropdown';

import Constant from '../../../../state/utils/constant';
import { showToast } from "../../../../redux/actions/toastAction";
import useWindowDimension from '../../../../hooks/useWindowDimension';
import './EditProfileDetails.scss';
const businessCategoryData = [
  {
    id: '1',
    title: 'Eco products',
    value: 'Eco products',
  },
  {
    id: '2',
    title: 'Endorsed green energy',
    value: 'Endorsed green energy',
  },
  {
    id: '3',
    title: 'Ecological',
    value: 'Ecological',
  },
  {
    id: '4',
    title: 'Conservation body membership',
    value: 'Conservation body membership',
  },
]
const UserEditProfile = (props) => {
  let { strings, onCancel, showToast } = props;
  let history = useNavigate();
  const dimensions = useWindowDimension();
  const [busy, setBusy] = useState(false);
  const [headerHeight, setHeaderHeight] = useState(0);
  const [stepForm, SetStepForm] = useState();
  const [businessCategory, setBusinessCategory] = useState({ id: '2', value: 'Endorsed green energy', title: "Endorsed green energy" });
  const [address, setAddress] = useState(null);
  const [formPhoneNumber, setFormPhoneNumber] = useState("996 336 9963");
  const [profile, setProfile] = useState(null);
  const [propertySizeModal, setPropertySizeModal] = useState(false);
  const [propertySizeForm, SetPropertySizeForm] = useState();
  const onFormSubmit = (data) => {
    setBusy(true);
    showToast({
      message: "Profile details have been updated successfully.",
      type: "success",
    });
    setTimeout(() => {
      onCancel();
      setBusy(false);
    }, 1000);
  };
  const onPropertySizeSubmit = (data) => {
    setPropertySizeModal(false);
  };
  const onTribesLogoChange = async (acceptedFiles) => {
    const reader = new FileReader();
    reader.addEventListener("load", (event) => {
      setProfile(event.target.result);
    });
    reader.readAsDataURL(acceptedFiles[0]);
  };
  useEffect(() => {
    setHeaderHeight(document.getElementsByClassName("userHeader")[0]?.offsetHeight);
  }, []);

  const editProfileForm = {
    fullName: {
      name: "fullName",
      validate: {
        required: {
          value: true,
        },
        pattern: {
          value: Constant.REGEX.NAME,
          message: strings["ONLY_ALPHABETICAL_CHARACTERS"],
        },
      },
    },
    email: {
      name: "email",
      validate: {
        required: {
          value: true,
          message: strings["EMAIL_ADDRESS_IS_REQUIRED"],
        },
        pattern: {
          value: Constant.REGEX.EMAIL,
          message: strings["EMAIL_ADDRESS_IS_INVALID"],
        },
      },
    },
    cunrtyCode: {
      name: "cunrtyCode",
      validate: {},
    },
    phoneNumber: {
      name: "phoneNumber",
      validate: {
        required: {
          value: true,
        }
      },
    },
    linkedin: {
      name: 'linkedin',
      validate: {
        required: {
          value: true,
        },
        pattern: {
          value: Constant.REGEX.LINKEDIN,
          message: strings["VALID_LINKEDIN_URL"],
        },
      },
    },
    bussinessName: {
      name: "bussinessName",
      validate: {
        required: {
          value: true,
        },
      },
    },
    businessCategory: {
      name: 'businessCategory',
      validate: {
        required: {
          value: true,
        }
      }
    },
    propertySize: {
      name: 'propertySize',
      validate: {
        required: {
          value: true,
        },
        pattern: {
          value: Constant.REGEX.NUMBER,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    },
    occupants: {
      name: 'occupants',
      validate: {
        required: {
          value: true,
        },
        pattern: {
          value: Constant.REGEX.NUMBER,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    },
    bussinessName: {
      name: "bussinessName",
      validate: {
        required: {
          value: true,
        },
      },
    },
    businessCategory: {
      name: 'businessCategory',
      validate: {
        required: {
          value: true,
        }
      }
    },
    address: {
      name: 'address',
      validate: {
        required: {
          value: true,
        },
      },
    },
    postCode: {
      name: 'postCode',
      validate: {
        required: {
          value: true,
        },
        pattern: {
          value: Constant.REGEX.UK_POSTCODE,
          message: strings["VALID_POSTCODE"],
        },
      },
    },
    relatedCharities: {
      name: 'relatedCharities',
      validate: {
        required: {
          value: true,
        }
      }
    }
  };
  const pSizeForm = {
    width: {
      name: "width",
      validate: {
        required: {
          value: false,
        },
        pattern: {
          value: Constant.REGEX.NUMBER,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    },
    length: {
      name: "length",
      validate: {
        required: {
          value: false,
        },
        pattern: {
          value: Constant.REGEX.NUMBER,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    },
    storeys: {
      name: "storeys",
      validate: {
        required: {
          value: false,
        },
        pattern: {
          value: Constant.REGEX.NUMBER,
          message: strings["ONLY_NUMERIC_VALUES"],
        },
      },
    },
  };

  return (
    <div className='editProfile'>
      <HookForm
        defaultForm={{}}
        init={(form) => SetStepForm(form)}
        onSubmit={(e) => onFormSubmit(e)}
      >
        {(formMethod) => {
          console.log("errror==>", formMethod?.formState?.errors);
          return (
            <div className="scrollView" style={{ height: dimensions.height - headerHeight - "px" }}>
              <Controller
                defaultValue=""
                name="image"
                control={formMethod.control}
                render={({ field: { onChange, value } }) => (
                  <FileUpload
                    onDrop={(acceptedFiles) => {
                      onChange(acceptedFiles);
                      onTribesLogoChange(acceptedFiles);
                    }}
                    accept="image/jpeg,image/jpg,image/png"
                  >
                    <div className="profileRound">
                      {profile ? (
                        <div className="uploadedImg">
                          <img src={profile} alt="" />
                          <div className="image">
                            <div className='hoverTxt'>
                              <i className="icon icon-camera" />
                              <p>{strings["CLICK_TO_CHANGE"]}</p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="uploadedImg">
                            <img src={'https://res.cloudinary.com/zudu/image/upload/v1657262509/Earth-Rising/Project-images/profile_placeholder.png'} alt="" />
                            <div className="image">
                              <div className='hoverTxt'>
                                <i className="icon icon-camera" />
                                <p>{strings["CLICK_TO_CHANGE"]}</p>
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </FileUpload>
                )}
              />
              <div className="fieldRow">
                <TextField
                  formMethod={formMethod}
                  rules={editProfileForm.fullName.validate}
                  name={editProfileForm.fullName.name}
                  errors={formMethod?.formState?.errors}
                  autoFocus={true}
                  type="text"
                  lableTitle={strings['FULL_NAME']}
                  placeholder={strings["ENTER_FULL_NAME"]}
                  isReqired={true}
                  defaultValue="Jacob Mark"
                />
                <TextField
                  formMethod={formMethod}
                  rules={editProfileForm.email.validate}
                  name={editProfileForm.email.name}
                  errors={formMethod?.formState?.errors}
                  autoFocus={true}
                  type="text"
                  lableTitle={strings['EMAIL']}
                  placeholder={strings["ENTER_YOUR_EMAIL_ADDRESS"]}
                  isReqired={true}
                  defaultValue="jacob.mark@gmail.com"
                />
                <div className="countryPhoneGroup">
                  <label className="label">{strings['PHONE_NUMBER']}<span>*</span></label>
                  <div className="phoneInline">
                    <Controller
                      lableTitle={strings['FULL_NAME']}
                      isReqired={true}
                      defaultValue={'44'}
                      control={formMethod?.control}
                      name={editProfileForm.cunrtyCode.name}
                      rules={editProfileForm.cunrtyCode.validate}
                      render={(props) => (<>
                        <PhoneInput
                          country={"us"}
                          disableSearchIcon={false}
                          enableSearch={false}
                          placeholder="+44"
                          value={formMethod.watch(
                            editProfileForm.cunrtyCode.name
                          )}
                          onChange={props.onChange}
                        />
                      </>
                      )}
                    />
                    <TextField
                      defaultValue="996 336 9963"
                      formMethod={formMethod}
                      rules={editProfileForm.phoneNumber.validate}
                      name={editProfileForm.phoneNumber.name}
                      errors={formMethod?.formState?.errors}
                      autoFocus={false}
                      required={false}
                      noTextfield={true}
                      onChange={(e) => {
                        setFormPhoneNumber(e);
                      }}
                      maskChar=""
                      maskType="999 999 9999"
                      placeholder={strings["ENTER_PHONE_NUMBER"]}
                      valueProp={formPhoneNumber}
                    />
                  </div>
                </div>

              </div>

              <div className="fieldRow">
                <TextField
                  formMethod={formMethod}
                  rules={editProfileForm.linkedin.validate}
                  name={editProfileForm.linkedin.name}
                  errors={formMethod?.formState?.errors}
                  autoFocus={false}
                  type="text"
                  lableTitle={strings['LINKEDIN_URL']}
                  placeholder={strings["URL"]}
                  defaultValue="https://www.linkedin.com/jacobmark"
                />
              </div>

              <div className="fieldRow">
                <TextField
                  formMethod={formMethod}
                  rules={editProfileForm.bussinessName.validate}
                  name={editProfileForm.bussinessName.name}
                  errors={formMethod?.formState?.errors}
                  autoFocus={false}
                  type="text"
                  lableTitle={strings['BUSINESS_NAME']}
                  placeholder={strings["ENTER_BUSINESS_NAME"]}
                  defaultValue='Dietrich LTD.'
                  isReqired={true}
                />
                <Controller
                  render={({
                    field: { onChange }
                  }) => (
                    <CustomDropdown
                      lableTitle={strings['BUSINESS_CATEGORY']}
                      isReqired={true}
                      placeholder={strings['SELECT_BUSINESS_CATEGORY']}
                      autoClose={"outside"}
                      dropDownItems={businessCategoryData}
                      align={"end"}
                      selectedValue={businessCategory}
                      onSelect={(evt) => {
                        onChange(evt);
                        setBusinessCategory(evt);
                      }}
                    />
                  )}
                  control={formMethod.control}
                  name={editProfileForm.businessCategory.name}
                  rules={editProfileForm.businessCategory.validate}
                  defaultValue={businessCategory}
                />
              </div>

              <div className="fieldRow">
                <TextField
                  formMethod={formMethod}
                  rules={editProfileForm.propertySize.validate}
                  name={editProfileForm.propertySize.name}
                  errors={formMethod?.formState?.errors}
                  autoFocus={false}
                  type="text"
                  lableTitle={strings['PROPERTY_SIZE_SQM']}
                  placeholder={strings["ENTER_PROPERTY_SIZE"]}
                  isReqired={true}
                  defaultValue="105"
                >
                  <span onClick={() => {
                    // setPropertySizeModal(true)
                  }} className="calculate">{strings["CALCULATE"]}</span>
                </TextField>
                <TextField
                  formMethod={formMethod}
                  rules={editProfileForm.occupants.validate}
                  name={editProfileForm.occupants.name}
                  errors={formMethod?.formState?.errors}
                  autoFocus={false}
                  type="text"
                  lableTitle={strings['NUMBER_OF_OCCUPANTS_EMPLOYEES']}
                  placeholder={strings["TOTAL_NUMBER_OF_OCCUPANTS_EMPLOYEES"]}
                  isReqired={true}
                  defaultValue='12'
                />

              </div>

              <div className="fieldRow">
                <TextField
                  formMethod={formMethod}
                  rules={editProfileForm.address.validate}
                  name={editProfileForm.address.name}
                  errors={formMethod?.formState?.errors}
                  autoFocus={false}
                  maxLength={100}
                  textarea='textarea'
                  onChange={(e) =>
                    setAddress(e.target.value)
                  }
                  lableTitle={strings['ADDRESS']}
                  placeholder={strings["YOUR_COMPANY_ADDRESS"]}
                  defaultValue="The Business Centre, 61 Wellfield Road, Roath, Cardiff CF24 3DG"
                  isReqired={true}
                />
                <p className="countValue">
                  {formMethod?.watch(
                    editProfileForm.address.name
                  )
                    ? formMethod?.watch(
                      editProfileForm.address.name
                    )?.length
                    : 0}
                  /100
                </p>
              </div>

              <div className="nextBtnInline">
                <CustomButton
                  title={strings["UPDATE_PROFILE"]}
                  className='update'
                  disabled={!formMethod?.formState.isValid}
                  onClick={() => {
                    props.onSubmit();
                  }}
                />
                <CustomButton
                  title={strings["CANCEL"]}
                  onClick={onCancel}
                  className="cancelBtn"
                />
              </div>
            </div>
          );
        }}
      </HookForm>
      <ModalPopup
        showModal={propertySizeModal}
        closeButton={true}
        onHide={() => { setPropertySizeModal(false); }}
        className="propertySizeModal"
      >
        <div className="header">
          <h6>{strings["PROPERTY_SIZE_SQM"]}</h6>
          <i onClick={() => { setPropertySizeModal(false); }} className="icon icon-Clear_Close-icon" />
        </div>
        <div className="modalBody">
          <HookForm
            defaultForm={{}}
            init={(form) => SetPropertySizeForm(form)}
            onSubmit={(e) => { onPropertySizeSubmit(e); }}
          >
            {(formMethod) => {
              return (
                <>
                  <div className="modalForm">
                    <TextField
                      formMethod={formMethod}
                      rules={pSizeForm.width.validate}
                      name={pSizeForm.width.name}
                      errors={formMethod?.formState?.errors}
                      autoFocus={true}
                      type="text"
                      lableTitle={strings['WIDTH']}
                      placeholder={strings["ENTER_WIDTH"]}
                    >
                      <span className="inputRight">{strings['FOOT']}</span>
                    </TextField>
                    <TextField
                      formMethod={formMethod}
                      rules={pSizeForm.length.validate}
                      name={pSizeForm.length.name}
                      errors={formMethod?.formState?.errors}
                      autoFocus={false}
                      type="text"
                      lableTitle={strings['LENGTH']}
                      placeholder={strings["ENTER_LENGTH"]}
                    >
                      <span className="inputRight">{strings['FOOT']}</span>
                    </TextField>
                    <TextField
                      formMethod={formMethod}
                      rules={pSizeForm.storeys.validate}
                      name={pSizeForm.storeys.name}
                      errors={formMethod?.formState?.errors}
                      autoFocus={false}
                      type="text"
                      lableTitle={strings['NUMBER_OF_STOREYS']}
                      placeholder={strings["NUMBER_OF_STOREYS"]}
                    />
                  </div>
                  <CustomButton
                    title={strings["CALCULATE"]}
                    type='submit'
                    disabled={false}
                  />
                </>
              );
            }}
          </HookForm>
        </div>
      </ModalPopup>
    </div>
  );
}

const mapStateToProps = (state) => { return {}; };

const mapDispatchToProps = {
  showToast,
};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(UserEditProfile));