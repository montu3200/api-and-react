import React, { useState, useEffect } from "react";
import './CheckBox.scss';

const CheckBox = (props) => {
    let { labelTitle, id, onCheckedChange, register, name, disabled, children } = props;
    const [checked, setChecked] = useState(!!props.checked)

    useEffect(() => {
        setChecked(props.checked)
    }, [props.checked])

    const onChecked = (e) => {
        setChecked(e.target.checked)
        onCheckedChange && onCheckedChange(e.target.checked)
    }

    return (
        <div className="checkboxMain">
            <div className="checkInline">
                <input type="checkbox" ref={register} disabled={disabled} name={name} value={labelTitle} id={id} className='checkbox' checked={checked} onChange={onChecked} />
                {checked ? <i className='icon icon-Checkbox_checked' /> : <i className='icon icon-Checkbox_blank' />}
                <label id="checkLabel" htmlFor={id}>{labelTitle} {children}</label>
            </div>
        </div>
    )
}

CheckBox.defaultProps = {
    id: '',
    checked: false,
    labelTitle: 'Title',
}

export default CheckBox;