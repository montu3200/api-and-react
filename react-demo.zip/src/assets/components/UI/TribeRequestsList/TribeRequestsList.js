import React, { useEffect, useState } from 'react';
import { multilanguage } from "redux-multilanguage";
import { connect } from "react-redux";

import SearchBox from '../SearchBox/SearchBox';
import ModalPopup from '../ModalPopup/ModalPopup';
import CustomButton from '../CustomButton/CustomButton';

import { showToast } from "../../../../redux/actions/toastAction";
import useWindowDimension from '../../../../hooks/useWindowDimension';

import './TribeRequestsList.scss';

const TribeRequestsList = (props) => {
  let { strings, showToast } = props;
  const dimensions = useWindowDimension();
  const [headerHeight, setHeaderHeight] = useState(0);
  const [pageTitleHeight, setPageTitleHeight] = useState(0);
  const [tabNavbarHeight, setTabNavbarHeight] = useState(0);
  const [searchRowHeight, setSearchRowHeight] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [rejectTribeModal, setRejectTribeModal] = useState(false);

  useEffect(() => {
    setHeaderHeight(document.getElementsByClassName("userHeader")[0]?.offsetHeight);
    setPageTitleHeight(document.getElementsByClassName("pageTitleRow")[0]?.offsetHeight);
    setTabNavbarHeight(document.getElementsByClassName("navCustomTab")[0]?.offsetHeight);
    setSearchRowHeight(document.getElementsByClassName("searchRow")[0]?.offsetHeight);
  }, []);

  const onPressAccept = () => {
    showToast({
      message: strings['REQUEST_ACCEPTED_SUCCESSFULY'],
      type: "success",
    });
  };
  const onPressConfirm = () => {
    setRejectTribeModal(false);
    showToast({
      message: strings['REQUEST_TO_JOIN_REJECTED'],
      type: "error",
    });
  };

  const tribeRequestsHeader = [
    { id: 1, title: strings['TRIBE_NAME'], sorting: true },
    { id: 2, title: strings['REQUEST_BY'], sorting: true },
    { id: 3, title: strings['ACTION'], sorting: false },
  ]

  const tribeRequestsList = [
    {
      id: 1,
      tribeName: 'Ade. Plagusa.',
      requestBy: 'John Wick',
    },
    {
      id: 2,
      tribeName: 'Reusable bag',
      requestBy: 'Jacob Mark',
    },
    {
      id: 3,
      tribeName: 'Ade. Plagusa 123',
      requestBy: 'john Will',
    }
  ]
  return (
    <>
      <div className="searchRow">
        <SearchBox
          placeholder={strings['SEARCH_TRIBE_BY_NAME']}
          value={searchText}
          onClear={() => {
            setSearchText("");
          }}
          onSearch={(e) => {
            setSearchText(e);
          }}
        />
      </div>
      <div className="tribeRequestsTbl">
        <ul className="tribeRequestsTableheaderList">
          {tribeRequestsHeader.map((item, index) => {
            return (
              <li key={index.toString()}>{(item.title)}{(item.sorting === true && tribeRequestsList.length !== 0) && <i className="icon icon-sort-icon"></i>}</li>
            )
          })}
        </ul>
        <ul className="tribeRequestsTable" style={{ maxHeight: (dimensions.height - headerHeight - pageTitleHeight - tabNavbarHeight - searchRowHeight - 110) }}>
          {tribeRequestsList.length === 0 &&
            <div className='notAnytribe'>
              <div>
                <i className="icon icon-No-records_empty-state" />
                <p>{strings['NO_RECENT_TRIBE_REQUESTS_FOUND']}</p>
              </div>
            </div>
          }
          {tribeRequestsList.map((item, index) => {
            return (
              <li key={index.toString()}>
                <p className="colone">{item.tribeName}</p>
                <p className="coltwo">{item.requestBy}</p>
                <div className="colthree">
                  <CustomButton type="button" title={strings["ACCEPT"]} onClick={() => {
                    onPressAccept()
                  }} />
                  <CustomButton type="button" className='reject' title={strings["REJECT"]} onClick={() => {
                    setRejectTribeModal(true)
                  }} />
                </div>
              </li>
            )
          })}
        </ul>
      </div>
      <ModalPopup
        showModal={rejectTribeModal}
        closeButton={true}
        onHide={() => { setRejectTribeModal(false); }}
        className="deletetribes"
      >
        <h6><i className='icon icon-logout_icon' /> {strings['REJECT_REQUEST']}</h6>
        <p>{strings['REJECT_THIS_REQUEST']}</p>
        <div className="btnInline">
          <CustomButton type="button" title={strings["YES"]} onClick={() => {
            onPressConfirm(false)
          }} />
          <CustomButton type="button" title={strings["NO"]} onClick={() => {
            setRejectTribeModal(false)
          }} />
        </div>
      </ModalPopup>
    </>
  )
}
const mapStateToProps = (state) => { return {}; };

const mapDispatchToProps = {
  showToast
};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(TribeRequestsList));