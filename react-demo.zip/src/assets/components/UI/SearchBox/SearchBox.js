import React from 'react';
import { connect } from 'react-redux';
import { multilanguage } from "redux-multilanguage";

import './SearchBox.scss';

const SearchBox = (props) => {
  let { placeholder, onSearch, onClear, value, strings, isDisabled = false } = props
  return (
    <div className="searchBox">
      <i className='icon icon-Search-icon' />
      <input type="text" name="focus" disabled={isDisabled} className="searchInput" value={value} placeholder={placeholder} onChange={(e) => { onSearch && onSearch(e.target.value) }} />
      {value !== undefined && value !== '' && <button className="close-icon" type="reset" onClick={() => { onClear && onClear(); }}>Clear</button>}
      {props.children}
    </div>
  );
}

const mapStateToProps = (state) => { return {}; };

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(multilanguage(SearchBox));