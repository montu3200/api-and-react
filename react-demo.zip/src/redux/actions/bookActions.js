export const SET_BOOK = 'SET_BOOK';

export const setBook = (isValue) => {
    return dispatch => {
        dispatch({
            type: SET_BOOK,
            payload: isValue
        });
    };
};
