import loaderReducer from "./loaderReducer";
import toastReducer from "./toastReducer";
import bookReducer from "./bookReducer";
import { combineReducers } from "redux";
import { createMultilanguageReducer } from "redux-multilanguage";

const rootReducer = combineReducers({
  multilanguage: createMultilanguageReducer({ currentLanguageCode: "en" }),
  loading: loaderReducer,
  toastReducer,
  bookReducer
});

export default rootReducer;
