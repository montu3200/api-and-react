import { SET_BOOK } from '../actions/bookActions';

const initState = {
    book: {}
};

const bookReducer = (state = initState, action) => {
    if (action.type === SET_BOOK) {
        return {
            ...state,
            book: action.payload
        };
    }

    return state;
};

export default bookReducer;
