import React from 'react';
import { connect } from 'react-redux';
import { Route, Routes } from 'react-router-dom';
import { AdminLayoutRoute } from './../../routes';

import AdminHeader from './AdminHeader/AdminHeader';

const AdminLayout = (props) => {
    return (
        <div className="main">
            <AdminHeader {...props} />
            <Routes>
                {AdminLayoutRoute.map((route, index) => {
                    return <Route
                        key={index}
                        exact={route.exact}
                        path={route.path}
                        element={route.component}
                    />;
                })}
            </Routes>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
    };
};

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(AdminLayout);
