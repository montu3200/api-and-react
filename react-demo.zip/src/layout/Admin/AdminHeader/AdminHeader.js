import React, { useState, useEffect } from "react";
import { Nav, Navbar, Dropdown, Offcanvas } from "react-bootstrap";
import { connect } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { multilanguage } from "redux-multilanguage";
import Constant from "../../../state/utils/constant";
import ModalPopup from "../../../assets/components/UI/ModalPopup/ModalPopup";
import CustomButton from "../../../assets/components/UI/CustomButton/CustomButton";
import { useLocation } from "react-router-dom";

import "./AdminHeader.scss";

const AdminHeader = (props) => {
  let { strings } = props;
  let history = useNavigate();
  const { pathname } = useLocation();

  const [isOpen, setIsOpen] = useState();
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [notificationList, setNotificationList] = useState([]);

  const notificationContent = [
    {
      date: "Today",
      data: [
        {
          title: "Lorem ipsum dolor sit amet",
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit accumsan vel auctor ligula dignissim pretium pulvinar lobortis. Sed fusce ornare sed volutpat nisl.",
        },
        {
          title: "Lorem ipsum dolor sit amet",
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit accumsan vel auctor ligula dignissim pretium pulvinar lobortis. Sed fusce ornare sed volutpat nisl.",
        },
        {
          title: "Lorem ipsum dolor sit amet",
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit accumsan vel auctor ligula dignissim pretium pulvinar lobortis. Sed fusce ornare sed volutpat nisl.",
        },
        {
          title: "Lorem ipsum dolor sit amet",
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit accumsan vel auctor ligula dignissim pretium pulvinar lobortis. Sed fusce ornare sed volutpat nisl.",
        },
      ],
    },
    {
      date: "10 june 2022",
      data: [
        {
          title: "Lorem ipsum dolor sit amet",
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit accumsan vel auctor ligula dignissim pretium pulvinar lobortis. Sed fusce ornare sed volutpat nisl.",
        },
        {
          title: "Lorem ipsum dolor sit amet",
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit accumsan vel auctor ligula dignissim pretium pulvinar lobortis. Sed fusce ornare sed volutpat nisl.",
        },
        {
          title: "Lorem ipsum dolor sit amet",
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit accumsan vel auctor ligula dignissim pretium pulvinar lobortis. Sed fusce ornare sed volutpat nisl.",
        },
        {
          title: "Lorem ipsum dolor sit amet",
          description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sit accumsan vel auctor ligula dignissim pretium pulvinar lobortis. Sed fusce ornare sed volutpat nisl.",
        },
      ],
    },
  ];

  useEffect(() => {
    setNotificationList(notificationContent);
  }, []);

  let activeMenu = "";

  if (pathname.indexOf("/customer") !== -1) {
    activeMenu = "customer";
  }
  // else if (pathname.indexOf('/admin/localauthority') !== -1) {
  //     activeMenu = 'localauthority'
  // }
  // else if (pathname.indexOf('/admin/alternec') !== -1 || pathname.indexOf('/admin/neclist') !== -1) {
  //     activeMenu = 'alternec'
  // }

  const onPressConfirm = (data) => {
    setShowLogoutModal(false);
    setTimeout(() => {
      history("/admin/login");
    }, 1000);
  };

  return (
    <>
      <div className="adminHeader">
        <div className="adminHeaderCenter">
          <Navbar expand="md">
            <div className="rightWrap">
              <Navbar.Toggle>
                <div className="icons">
                  <span className="icon-24"></span>
                </div>
              </Navbar.Toggle>
              <Navbar.Collapse className="drawerMenu">
                <Nav className="me-auto menu" activeKey={activeMenu}>
                  <Nav.Link eventKey="customer" as={Link} to="/admin/customer">
                    {strings["CUSTOMER"]}
                  </Nav.Link>
                  
                </Nav>
              </Navbar.Collapse>
              
            </div>
          </Navbar>
        </div>
      </div>

      <Offcanvas
        className="notiCanvas"
        show={show}
        onHide={handleClose}
        {...props}
        placement="end"
      >
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>{strings["NOTIFICATIONS"]}</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          {notificationList.length == 0 && (
            <div className="notAnynotification">
              {strings["NOT_ANY_NOTIFICATION"]}
            </div>
          )}
          {notificationList.map((item, index) => {
            return (
              <div key={index.toString()}>
                <p className="dateTitle">{item.date}</p>
                {item.data.map((item, index) => {
                  return (
                    <Link
                      to="#"
                      onClick={() => {
                        handleClose(true);
                      }}
                    >
                      <h6>{item.title}</h6>
                      <p>{item.description}</p>
                    </Link>
                  );
                })}
              </div>
            );
          })}
        </Offcanvas.Body>
      </Offcanvas>

      <ModalPopup
        showModal={showLogoutModal}
        closeButton={true}
        onHide={() => {
          setShowLogoutModal(false);
        }}
        className="logoutModal"
      >
        <h6>
          <i className="icon icon-logout_icon" /> {strings["LOGOUT"]}
        </h6>
        <p>{strings["ARE_YOU_LOGOUT"]}</p>
        <div className="btnInline">
          <CustomButton
            type="button"
            title={strings["YES"]}
            onClick={() => {
              onPressConfirm(false);
            }}
          />
          <CustomButton
            type="button"
            title={strings["NO"]}
            onClick={() => {
              setShowLogoutModal(false);
            }}
          />
        </div>
      </ModalPopup>
    </>
  );
};

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = {};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(multilanguage(AdminHeader));
